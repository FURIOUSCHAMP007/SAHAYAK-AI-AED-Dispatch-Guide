import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { AuthProvider } from '@/lib/auth';
import { Toaster } from '@/components/ui/toaster';
import { IncidentProvider } from '@/lib/incident-context';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata: Metadata = {
  title: 'SAHAYAK Admin Central',
  description: 'Manage and monitor your fleet of SAHAYAK AED devices.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <AuthProvider>
          <IncidentProvider>
            {children}
          </IncidentProvider>
        </AuthProvider>
        <Toaster />
      </body>
    </html>
  );
}
