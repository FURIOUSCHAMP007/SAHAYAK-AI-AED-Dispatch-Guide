import { LoginForm } from "@/components/auth/login-form";
import { Logo } from "@/components/icons";

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center text-center mb-8">
            <div className="p-3 rounded-full bg-primary text-primary-foreground mb-4">
                <Logo className="h-8 w-8" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">SAHAYAK Admin Central</h1>
            <p className="text-muted-foreground">Enter your credentials to access the dashboard</p>
        </div>
        <LoginForm />
      </div>
    </div>
  );
}
