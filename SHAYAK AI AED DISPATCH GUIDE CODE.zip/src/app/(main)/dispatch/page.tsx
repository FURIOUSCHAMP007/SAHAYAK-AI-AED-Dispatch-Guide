
import DispatchDashboard from "@/components/dispatch/dispatch-dashboard";

export default function DispatchPage() {
    return <DispatchDashboard />;
}
