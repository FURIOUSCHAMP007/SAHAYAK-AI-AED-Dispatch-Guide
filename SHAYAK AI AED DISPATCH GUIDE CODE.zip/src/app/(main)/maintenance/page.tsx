"use client"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Wrench } from "lucide-react"
import { useIncidents } from "@/lib/incident-context"

export default function MaintenancePage() {
  const { devices } = useIncidents()
  const maintenanceDevices = devices.filter(
    (d) => d.status === "Maintenance_Required"
  )

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-full bg-primary/10 text-primary shrink-0">
            <Wrench className="h-6 w-6" />
          </div>
          <div className="flex-1">
            <CardTitle>Predictive Maintenance Alerts</CardTitle>
            <CardDescription>
              AI-flagged devices that may require maintenance soon.
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {maintenanceDevices.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Device Name</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Battery</TableHead>
                <TableHead>Last Log</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {maintenanceDevices.map((device) => (
                <TableRow key={device.id}>
                  <TableCell className="font-medium">{device.name}</TableCell>
                  <TableCell>{device.address}</TableCell>
                  <TableCell>{device.batteryLevel}%</TableCell>
                  <TableCell className="max-w-xs truncate">{device.deviceLogs}</TableCell>
                  <TableCell>
                    <Badge variant="destructive">
                        <AlertTriangle className="mr-2 h-4 w-4" />
                        Maintenance Required
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center py-10 text-muted-foreground">
            <p>No devices currently require maintenance.</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
