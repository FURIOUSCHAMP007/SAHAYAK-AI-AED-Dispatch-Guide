import { notFound } from "next/navigation"
import { incidents as allIncidents } from "@/lib/data"
import { ecgPlotData } from "@/lib/data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, MapPin, HardDrive, User } from "lucide-react"
import EcgChart from "@/components/incidents/ecg-chart"
import IncidentAnalysis from "@/components/incidents/incident-analysis"
import IncidentSummary from "@/components/incidents/incident-summary"
import Image from "next/image"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import CprAnalysis from "@/components/incidents/cpr-analysis"
import IncidentAudioReport from "@/components/incidents/incident-audio-report"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import IncidentAudioSummary from "@/components/incidents/incident-audio-summary"

// Note: This is now a Server Component to align with modern Next.js practices.
export default function IncidentPage({ params }: { params: { id: string } }) {
  const incident = allIncidents.find((inc) => inc.id === params.id)

  if (!incident) {
    return notFound()
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      <div className="lg:col-span-4 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Location</CardTitle>
            <MapPin className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{incident.location}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Timestamp</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{new Date(incident.timestamp).toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Device</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{incident.deviceName}</div>
            <p className="text-xs text-muted-foreground">ID: {incident.deviceId}</p>
          </CardContent>
        </Card>
         <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patient Data</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold truncate">{incident.patientData}</div>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-4">
        <IncidentSummary incident={incident} />
      </div>

      <div className="lg:col-span-4">
        <IncidentAudioSummary incident={incident} />
      </div>
      
      <div className="lg:col-span-4">
        <IncidentAudioReport incident={incident} />
      </div>

      <div className="lg:col-span-4">
        <IncidentAnalysis incident={incident} />
      </div>
      
      <div className="lg:col-span-4">
        <CprAnalysis incident={incident} />
      </div>

      <div className="lg:col-span-4">
        <Card>
          <CardHeader>
            <CardTitle>ECG Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="plot">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="plot">Live Plot</TabsTrigger>
                <TabsTrigger value="snapshot">Snapshot</TabsTrigger>
              </TabsList>
              <TabsContent value="plot">
                <div className="mt-4">
                    <EcgChart data={ecgPlotData} />
                </div>
              </TabsContent>
              <TabsContent value="snapshot">
                 <div className="p-4 mt-4 border rounded-md bg-muted/50">
                    <Image
                        src={incident.ecgDataUrl}
                        alt="ECG Data Snapshot"
                        width={800}
                        height={200}
                        className="rounded-md object-cover w-full"
                        data-ai-hint="ecg chart"
                    />
                 </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

       <div className="lg:col-span-4">
        <Card>
          <CardHeader>
            <CardTitle>Event Timeline</CardTitle>
          </CardHeader>
          <CardContent>
             <Table>
                <TableHeader>
                    <TableRow>
                    <TableHead>Event</TableHead>
                    <TableHead className="text-right">Time</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {incident.timeline.map((event, index) => (
                    <TableRow key={index}>
                        <TableCell>{event.event}</TableCell>
                        <TableCell className="text-right">{event.time}</TableCell>
                    </TableRow>
                    ))}
                </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

    </div>
  )
}
