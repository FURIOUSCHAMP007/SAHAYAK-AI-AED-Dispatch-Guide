"use client"

import Link from "next/link"
import { useIncidents } from "@/lib/incident-context"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"

export default function IncidentsPage() {
  const { incidents } = useIncidents();

  return (
    <Card>
      <CardHeader>
        <CardTitle>All Incidents</CardTitle>
        <CardDescription>Browse the log of all recorded incidents.</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Device Name</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Timestamp</TableHead>
              <TableHead>Patient Summary</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {incidents.map((incident) => (
              <TableRow key={incident.id}>
                <TableCell className="font-medium">{incident.deviceName}</TableCell>
                <TableCell>{incident.location}</TableCell>
                <TableCell>{formatDistanceToNow(new Date(incident.timestamp), { addSuffix: true })}</TableCell>
                <TableCell className="max-w-xs truncate">{incident.patientData}</TableCell>
                <TableCell className="text-right">
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/incidents/${incident.id}`}>View Details</Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
