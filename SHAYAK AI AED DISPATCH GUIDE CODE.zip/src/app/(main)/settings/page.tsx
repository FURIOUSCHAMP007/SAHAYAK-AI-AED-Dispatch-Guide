import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings } from "lucide-react";

export default function SettingsPage() {
    return (
        <Card>
            <CardHeader>
                <div className="flex items-start gap-4">
                    <div className="p-3 rounded-full bg-primary/10 text-primary">
                        <Settings className="h-6 w-6" />
                    </div>
                    <div>
                        <CardTitle>Settings</CardTitle>
                        <CardDescription>
                            Manage your account and application settings.
                        </CardDescription>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="text-center py-10 text-muted-foreground">
                    <p>Settings page is under construction.</p>
                </div>
            </CardContent>
        </Card>
    )
}
