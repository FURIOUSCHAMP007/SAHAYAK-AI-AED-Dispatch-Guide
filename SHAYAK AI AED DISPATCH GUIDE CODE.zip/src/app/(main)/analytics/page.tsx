import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChartHorizontal } from "lucide-react";
import DeviceStatusChart from "@/components/analytics/device-status-chart";
import BatteryLevelsChart from "@/components/analytics/battery-levels-chart";
import IncidentTrendChart from "@/components/analytics/incident-trend-chart";
import MaintenanceHistoryChart from "@/components/analytics/maintenance-history-chart";
import UsagePatternChart from "@/components/analytics/usage-pattern-chart";
import IncidentTypeChart from "@/components/analytics/incident-type-chart";

export default function AnalyticsPage() {
    return (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="lg:col-span-2">
                <Card>
                    <CardHeader>
                        <div className="flex items-start gap-4">
                            <div className="p-3 rounded-full bg-primary/10 text-primary">
                                <BarChartHorizontal className="h-6 w-6" />
                            </div>
                            <div>
                                <CardTitle>Data Analytics</CardTitle>
                                <CardDescription>
                                    Visualizing the health, status, and history of your AED network.
                                </CardDescription>
                            </div>
                        </div>
                    </CardHeader>
                </Card>
            </div>
            
            <DeviceStatusChart />
            <UsagePatternChart />

            <div className="lg:col-span-2">
                <IncidentTypeChart />
            </div>

            <div className="lg:col-span-2">
                <BatteryLevelsChart />
            </div>
            <div className="lg:col-span-2">
                <IncidentTrendChart />
            </div>
             <div className="lg:col-span-2">
                <MaintenanceHistoryChart />
            </div>

        </div>
    )
}
