
"use client"

import * as React from "react";
import AedMap from '@/components/dashboard/aed-map';
import DeviceList from '@/components/dashboard/device-list';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useIncidents } from '@/lib/incident-context';
import { Activity, AlertTriangle, ShieldCheck, PhoneForwarded } from 'lucide-react';
import CallerReportForm from "@/components/incidents/caller-report-form";

export default function DashboardPage() {
    const { incidents, devices } = useIncidents();
    const [selectedLocation, setSelectedLocation] = React.useState<{lat: number, lng: number} | null>(null);

    const operationalDevices = devices.filter(d => d.status === 'Operational').length;
    const activeIncidents = devices.filter(d => d.status === 'Active_Incident').length;
    const maintenanceRequired = devices.filter(d => d.status === 'Maintenance_Required').length;

    const handleMapClick = (lngLat: { lat: number; lng: number }) => {
        setSelectedLocation(lngLat);
    };

  return (
    <div className="grid gap-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Operational Devices</CardTitle>
                    <ShieldCheck className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{operationalDevices}</div>
                    <p className="text-xs text-muted-foreground">out of {devices.length} total devices</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Active Incidents</CardTitle>
                    <Activity className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-red-500">{activeIncidents}</div>
                    <p className="text-xs text-muted-foreground">currently active</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Maintenance Required</CardTitle>
                    <AlertTriangle className="h-4 w-4 text-orange-500" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-orange-500">{maintenanceRequired}</div>
                    <p className="text-xs text-muted-foreground">devices need attention</p>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Incidents</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{incidents.length}</div>
                    <p className="text-xs text-muted-foreground">in the system</p>
                </CardContent>
            </Card>
        </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <AedMap devices={devices} onMapClick={handleMapClick} incidentLocation={selectedLocation} />
        </div>
        <div className="grid gap-6">
          <Card>
              <CardHeader>
                   <div className="flex items-center gap-4">
                      <div className="p-3 rounded-full bg-primary/10 text-primary">
                          <PhoneForwarded className="h-6 w-6" />
                      </div>
                      <div>
                          <CardTitle>Report New Incident</CardTitle>
                          <CardDescription>
                              Click map to set location or enter manually.
                          </CardDescription>
                      </div>
                  </div>
              </CardHeader>
              <CardContent>
                  <CallerReportForm selectedLocation={selectedLocation} />
              </CardContent>
          </Card>
        </div>
      </div>
      
      <DeviceList devices={devices} />
      
    </div>
  );
}
