
"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { analyzeCprPerformance, CprAnalysisOutput } from "@/ai/flows/cpr-analysis"
import { Incident } from "@/types"
import { AlertCircle, Eye, Lightbulb, CheckCircle } from "lucide-react"

interface CprAnalysisProps {
  incident: Incident
}

export default function CprAnalysis({ incident }: CprAnalysisProps) {
  const [analysis, setAnalysis] = React.useState<CprAnalysisOutput | null>(null)
  const [isLoading, setIsLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  const handleAnalysis = async () => {
    setIsLoading(true)
    setError(null)
    setAnalysis(null)
    try {
      const result = await analyzeCprPerformance({
        eventLog: incident.eventLog,
      })
      setAnalysis(result)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
            <div>
                <CardTitle className="flex items-center gap-2">
                    <Eye className="h-6 w-6 text-primary" />
                    AI Eyes: CPR Quality Analysis
                </CardTitle>
                <CardDescription>
                    Post-incident analysis of CPR performance based on event logs.
                </CardDescription>
            </div>
            <Button onClick={handleAnalysis} disabled={isLoading} variant="outline">
              {isLoading ? "Analyzing..." : "Analyze"}
            </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading && <AnalysisSkeleton />}
        {error && <ErrorAlert message={error} />}
        {analysis && <AnalysisResult result={analysis} />}
        {!isLoading && !error && !analysis && (
            <div className="text-center text-muted-foreground p-8 border-dashed border-2 rounded-lg">
                <Lightbulb className="mx-auto h-8 w-8 mb-2" />
                <p>Click "Analyze" to generate AI insights into CPR quality.</p>
            </div>
        )}
      </CardContent>
    </Card>
  )
}

const AnalysisSkeleton = () => (
    <div className="space-y-4">
        <div className="flex justify-between items-center">
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-6 w-1/5" />
        </div>
        <Skeleton className="h-5 w-full" />
        <div className="space-y-2 pt-4">
            <Skeleton className="h-4 w-1/3" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
        </div>
    </div>
)

const ErrorAlert = ({ message }: { message: string }) => (
    <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Analysis Failed</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
    </Alert>
)

const AnalysisResult = ({ result }: { result: CprAnalysisOutput }) => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Overall Quality Score</h3>
        <div className="text-lg font-bold text-primary">{result.cprScore} / 100</div>
      </div>
      <Progress value={result.cprScore} className="w-full" />

      <div>
        <h4 className="font-semibold mb-2">Feedback:</h4>
        <p className="text-sm text-muted-foreground">{result.feedback}</p>
      </div>

      <div>
        <h4 className="font-semibold mb-2">Recommendations:</h4>
        <ul className="list-disc pl-5 space-y-1 text-sm text-muted-foreground">
          {result.recommendations.map((rec, index) => (
            <li key={index}>{rec}</li>
          ))}
        </ul>
      </div>
    </div>
)
