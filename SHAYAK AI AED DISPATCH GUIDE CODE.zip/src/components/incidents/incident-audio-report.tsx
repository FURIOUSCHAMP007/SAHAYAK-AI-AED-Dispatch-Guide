
"use client"

import * as React from "react"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import type { Incident } from "@/types"
import { malePatientScript, femalePatientScript, type ScriptItem } from "@/lib/scripts"
import { Ear, Lightbulb, User, UserCog, AlertCircle } from "lucide-react"
import { generateCprAedInstructions } from "@/ai/flows/generate-cpr-aed-instructions"

// Helper component to format the script
const FormattedScript = ({ script }: { script: ScriptItem[] }) => {
    return (
        <div>
            {script.map((item, index) => {
                 const content = item.content.replace(/\[Instructor \d\]\s*/, '');
                switch (item.type) {
                    case 'heading':
                        return <p key={index} className="font-bold mt-4 mb-2 text-foreground">{content}</p>;
                    case 'text':
                         const speakerPrefix = item.speaker === 'Instructor 2' ? 'font-semibold text-primary' : '';
                         return <p key={index} className={speakerPrefix}>{content}</p>;
                    case 'image':
                        return (
                           <div key={index} className="my-4 p-2 border rounded-md bg-background flex justify-center">
                             <Image
                                src={item.content}
                                alt={item.alt || 'Instructional image'}
                                width={300}
                                height={200}
                                className="rounded-md object-contain"
                                data-ai-hint={item.hint || ''}
                            />
                           </div>
                        );
                    case 'space':
                         return <div key={index} className="h-4" />;
                    default:
                        return null;
                }
            })}
        </div>
    );
};

interface IncidentAudioReportProps {
  incident: Incident
}

export default function IncidentAudioReport({ incident }: IncidentAudioReportProps) {
  const [audioDataUri, setAudioDataUri] = React.useState<string | null>(null)
  const [script, setScript] = React.useState<ScriptItem[] | null>(null);
  const [isLoading, setIsLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null);
  const [currentScenario, setCurrentScenario] = React.useState<'male' | 'female' | null>(null);

  const handleShowGuide = async (scenario: 'male' | 'female') => {
    const selectedScript = scenario === 'male' ? malePatientScript : femalePatientScript;
    
    // Immediately show the script
    setScript(selectedScript);
    setCurrentScenario(scenario);

    // Reset previous state and start loading audio
    setIsLoading(true);
    setError(null);
    setAudioDataUri(null);

    try {
        const result = await generateCprAedInstructions({ scenario });
        setAudioDataUri(result.audioDataUri);
    } catch (err) {
       const errorMessage = err instanceof Error ? err.message : "An unexpected error occurred during audio generation.";
       setError(errorMessage);
       console.error("Audio guide error:", err);
    } finally {
        setIsLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start flex-wrap gap-2">
            <div>
                <CardTitle className="flex items-center gap-2">
                    <Ear className="h-6 w-6 text-primary" />
                    CPR &amp; AED Audio Guide
                </CardTitle>
                <CardDescription>Listen to AI-powered audio instructions for CPR and AED use.</CardDescription>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button onClick={() => handleShowGuide('male')} disabled={isLoading && currentScenario === 'male'} variant="outline" size="sm">
                <User className="mr-2 h-4 w-4" /> 
                {isLoading && currentScenario === 'male' ? 'Loading Audio...' : 'Show Male Guide'}
              </Button>
              <Button onClick={() => handleShowGuide('female')} disabled={isLoading && currentScenario === 'female'} variant="outline" size="sm">
                <UserCog className="mr-2 h-4 w-4" /> 
                {isLoading && currentScenario === 'female' ? 'Loading Audio...' : 'Show Female Guide'}
              </Button>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        {error && <ErrorAlert message={error} />}
        
        {script ? (
            <div className="flex flex-col gap-4">
                {isLoading && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Skeleton className="h-10 w-full" />
                  </div>
                )}
                {audioDataUri && (
                    <audio controls src={audioDataUri} className="w-full">
                        Your browser does not support the audio element.
                    </audio>
                )}
                 <div className="text-sm text-muted-foreground p-4 border rounded-md bg-muted/50 h-[450px] overflow-y-auto">
                    <FormattedScript script={script} />
                 </div>
            </div>
        ) : (
             <div className="text-center text-muted-foreground p-8 border-dashed border-2 rounded-lg">
                <Lightbulb className="mx-auto h-8 w-8 mb-2" />
                <p>Click a button above to load the appropriate AI-generated audio guide.</p>
            </div>
        )}
      </CardContent>
    </Card>
  )
}

const ErrorAlert = ({ message }: { message: string }) => (
    <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Audio Generation Failed</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
    </Alert>
);
