
"use client"

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { reportIncident } from "@/ai/flows/report-incident";
import { triageIncident } from "@/ai/flows/triage-incident";
import { type TriageIncidentOutput } from "@/ai/schemas/incident-report";
import { ReportIncidentInputSchema, type ReportIncidentInput } from "@/ai/schemas/incident-report";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Loader2, Send, Wand2, ShieldQuestion, ListChecks } from "lucide-react";
import { useRouter } from "next/navigation";
import { useIncidents } from "@/lib/incident-context";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Progress } from "../ui/progress";
import { Separator } from "../ui/separator";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

const incidentTypes = [
    "Cardiac Arrest",
    "Breathing Problem",
    "Chest Pain",
    "Fall / Injury",
    "Unconscious / Fainting",
    "Seizure",
    "Other Medical",
];

interface CallerReportFormProps {
    selectedLocation: { lat: number, lng: number } | null;
}

export default function CallerReportForm({ selectedLocation }: CallerReportFormProps) {
    const { toast } = useToast();
    const router = useRouter();
    const { addIncident } = useIncidents();
    
    const [analysisResult, setAnalysisResult] = React.useState<TriageIncidentOutput | null>(null);
    const [isLoading, setIsLoading] = React.useState(false);
    const [isDispatching, setIsDispatching] = React.useState(false);
    const [error, setError] = React.useState<string | null>(null);

    const form = useForm<ReportIncidentInput>({
        resolver: zodResolver(ReportIncidentInputSchema),
        defaultValues: {
            callerName: "",
            callerNumber: "",
            location: "",
            incidentDetails: "",
        },
    });

    React.useEffect(() => {
        if (selectedLocation) {
            form.setValue('location', `${selectedLocation.lat.toFixed(6)}, ${selectedLocation.lng.toFixed(6)}`);
        }
    }, [selectedLocation, form]);


    const incidentDetails = form.watch("incidentDetails");

    async function handleAnalyze() {
        if (!incidentDetails) {
            form.setError("incidentDetails", { type: "manual", message: "Please provide incident details before analyzing." });
            return;
        }
        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);
        try {
            const result = await triageIncident({ incidentDetails });
            setAnalysisResult(result);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "An unexpected error occurred during analysis.";
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    }

    async function handleDispatch() {
        if (!analysisResult) {
            toast({
                variant: "destructive",
                title: "Analysis Required",
                description: "Please analyze the report with AI before dispatching.",
            });
            return;
        }

        setIsDispatching(true);
        setError(null);
        try {
            const values = form.getValues();
            const result = await reportIncident(values);
            addIncident(result, analysisResult);
            toast({
                title: "Incident Reported & Dispatched",
                description: `New incident ${result.incidentId} has been created and resources assigned.`,
            });
            // Reset form after successful dispatch
            form.reset();
            setAnalysisResult(null);
            
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "An unexpected error occurred during dispatch.";
            setError(errorMessage);
            toast({
                variant: "destructive",
                title: "Failed to Dispatch",
                description: errorMessage,
            });
        } finally {
            setIsDispatching(false);
        }
    }

    return (
        <div className="space-y-4">
            <Form {...form}>
                <form className="space-y-4">
                    <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Incident Location</FormLabel>
                            <FormControl>
                                <Input placeholder="Click map or enter address..." {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    
                    <FormField
                        control={form.control}
                        name="incidentDetails"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Incident Details</FormLabel>
                            <FormControl>
                                <Textarea
                                    placeholder="Describe the incident..."
                                    className="min-h-[100px]"
                                    {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />

                    <div className="flex justify-end">
                        <Button type="button" onClick={handleAnalyze} disabled={isLoading || !incidentDetails}>
                             {isLoading ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Analyzing...
                                </>
                             ) : (
                                <>
                                    <Wand2 className="mr-2 h-4 w-4" />
                                    Analyze with AI
                                </>
                             )}
                        </Button>
                    </div>
                </form>
            </Form>
            
            {error && <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>}
            
            {analysisResult && (
                <div className="space-y-4 pt-4 border-t animate-in fade-in-50">
                    <div className="flex items-center gap-2 text-primary font-semibold">
                        <ShieldQuestion className="h-5 w-5"/>
                        AI Triage & Dispatch Plan
                    </div>
                     <div>
                        <Label htmlFor="incident-type">AI Suggested Incident Type</Label>
                        <Select 
                            value={analysisResult.incidentType} 
                            onValueChange={(value) => setAnalysisResult({...analysisResult, incidentType: value as any})}
                        >
                            <SelectTrigger id="incident-type">
                                <SelectValue placeholder="Select incident type" />
                            </SelectTrigger>
                            <SelectContent>
                                {incidentTypes.map(type => (
                                    <SelectItem key={type} value={type}>{type}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                     </div>
                    
                    <div>
                        <Label>Confidence Score</Label>
                        <div className="flex items-center gap-2">
                            <Progress value={analysisResult.confidenceScore} className="w-full" />
                            <span className="font-bold text-primary">{analysisResult.confidenceScore}%</span>
                        </div>
                    </div>

                    <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2 text-sm"><ListChecks className="h-4 w-4 text-primary" />Dispatcher Protocol</h4>
                        <ul className="list-disc pl-5 space-y-1 text-xs text-muted-foreground bg-muted/50 p-3 rounded-md border">
                            {analysisResult.criticalQuestions.map((q, i) => <li key={i}>{q}</li>)}
                        </ul>
                    </div>
                    
                    <Separator />
                    
                    <Button className="w-full" onClick={handleDispatch} disabled={isDispatching}>
                        {isDispatching ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Confirming Dispatch...
                            </>
                        ) : (
                            <>
                                <Send className="mr-2 h-4 w-4" />
                                Confirm & Dispatch
                            </>
                        )}
                    </Button>
                </div>
            )}
        </div>
    );
}
