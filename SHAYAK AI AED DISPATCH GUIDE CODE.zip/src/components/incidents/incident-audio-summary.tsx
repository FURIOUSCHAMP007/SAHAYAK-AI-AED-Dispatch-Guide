
"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { generateIncidentAudioSummary, IncidentAudioSummaryOutput } from "@/ai/flows/incident-audio-summary"
import { Incident } from "@/types"
import { AlertCircle, Lightbulb, Volume2 } from "lucide-react"

interface IncidentAudioSummaryProps {
  incident: Incident
}

export default function IncidentAudioSummary({ incident }: IncidentAudioSummaryProps) {
  const [summary, setSummary] = React.useState<IncidentAudioSummaryOutput | null>(null)
  const [isLoading, setIsLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  const handleGenerateSummary = async () => {
    setIsLoading(true)
    setError(null)
    setSummary(null)
    try {
      const result = await generateIncidentAudioSummary({ incident })
      setSummary(result)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred during audio summary generation.";
      setError(errorMessage)
      console.error("Audio summary error:", err);
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
            <div>
                <CardTitle className="flex items-center gap-2">
                    <Volume2 className="h-6 w-6 text-primary" />
                    AI Audio Debrief
                </CardTitle>
                <CardDescription>Listen to a spoken summary of the incident.</CardDescription>
            </div>
             <Button onClick={handleGenerateSummary} disabled={isLoading} variant="outline">
              {isLoading ? "Generating..." : "Generate"}
            </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading && <AudioSkeleton />}
        {error && <ErrorAlert message={error} />}
        {summary && <AudioResult result={summary} />}
        {!isLoading && !error && !summary && (
             <div className="text-center text-muted-foreground p-8 border-dashed border-2 rounded-lg">
                <Lightbulb className="mx-auto h-8 w-8 mb-2" />
                <p>Click "Generate" to create an audio summary.</p>
            </div>
        )}
      </CardContent>
    </Card>
  )
}

const AudioSkeleton = () => (
    <div className="space-y-4">
        <Skeleton className="h-14 w-full" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
    </div>
)

const ErrorAlert = ({ message }: { message: string }) => (
    <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Audio Generation Failed</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
    </Alert>
)

const AudioResult = ({ result }: { result: IncidentAudioSummaryOutput }) => (
    <div className="space-y-4">
        <audio controls src={result.audioDataUri} className="w-full">
            Your browser does not support the audio element.
        </audio>
        <p className="text-sm text-muted-foreground p-4 border rounded-md bg-muted/50">
            <strong>Transcript:</strong> {result.textSummary}
        </p>
    </div>
)
