import type { SVGProps } from 'react';

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 256 256"
      width="24"
      height="24"
      {...props}
    >
      <g fill="none">
        <rect
          width="256"
          height="256"
          fill="#D92727"
          rx="40"
          ry="40"
          
        />
        <path
          fill="#ffffff"
          d="m183.16 220.08-41.9-72.93a20.4 20.4 0 0 0-35.21 0l-41.91 72.93a20.4 20.4 0 0 0 17.6 30.6h83.82a20.4 20.4 0 0 0 17.6-30.6Z"
        />
        <path
          fill="#D92727"
          d="m142.18 163.66-10.4-18.02h22.69l-19.11 33.1-6.19-10.72 13.01-22.54Z"
        />
        <path
          fill="#ffffff"
          d="M74.19 82.52h17.15l23.16 40.11 23.15-40.11h17.16L130.5 129.56zM83.47 24.08h31.83v20.4h-10.9v23.58h-10.02V44.48H83.47z"
        />
      </g>
    </svg>
  );
}
