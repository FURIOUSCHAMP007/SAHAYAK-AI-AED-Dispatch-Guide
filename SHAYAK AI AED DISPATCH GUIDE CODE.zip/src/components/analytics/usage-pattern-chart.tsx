"use client"

import * as React from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { useIncidents } from "@/lib/incident-context"

type UsagePattern = "Low" | "Moderate" | "High" | "Active";

const patternColors: Record<UsagePattern, string> = {
  "Low": "hsl(var(--chart-1))",
  "Moderate": "hsl(var(--chart-2))",
  "High": "hsl(var(--chart-4))",
  "Active": "hsl(var(--chart-5))",
}

export default function UsagePatternChart() {
  const { devices } = useIncidents()
  const patternCounts = devices.reduce((acc, device) => {
    let pattern: UsagePattern = "Low"; // Default
    const usage = device.usagePatterns.toLowerCase();
    if (usage.includes("high")) pattern = "High";
    else if (usage.includes("moderate")) pattern = "Moderate";
    else if (usage.includes("active")) pattern = "Active";
    else if (usage.includes("low")) pattern = "Low";
    
    acc[pattern] = (acc[pattern] || 0) + 1
    return acc
  }, {} as Record<UsagePattern, number>)

  const data = Object.entries(patternCounts).map(([name, value]) => ({
    name: name,
    value,
    fill: patternColors[name as UsagePattern],
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Device Usage Patterns</CardTitle>
        <CardDescription>A breakdown of how frequently devices are used or tested.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Tooltip
                cursor={{ fill: "hsl(var(--muted))" }}
                contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    borderColor: "hsl(var(--border))",
                }}
              />
              <Legend />
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={90}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
