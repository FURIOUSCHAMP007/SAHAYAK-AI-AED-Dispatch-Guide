"use client"

import * as React from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Cell } from "recharts"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { useIncidents } from "@/lib/incident-context"

type BatteryStatus = "Healthy" | "Medium" | "Low" | "Critical";

const statusColors: Record<BatteryStatus, string> = {
  "Healthy": "hsl(var(--chart-2))",
  "Medium": "hsl(var(--chart-4))",
  "Low": "hsl(var(--chart-3))",
  "Critical": "hsl(var(--destructive))",
}

export default function BatteryLevelsChart() {
  const { devices } = useIncidents();

  const chartData = React.useMemo(() => {
     const statusCounts: Record<BatteryStatus, number> = {
        "Critical": 0,
        "Low": 0,
        "Medium": 0,
        "Healthy": 0,
     };

     devices.forEach(device => {
        if (device.batteryLevel <= 25) {
            statusCounts["Critical"]++;
        } else if (device.batteryLevel <= 50) {
            statusCounts["Low"]++;
        } else if (device.batteryLevel <= 75) {
            statusCounts["Medium"]++;
        } else {
            statusCounts["Healthy"]++;
        }
     });

     return [
        { status: "Critical (0-25%)", count: statusCounts.Critical, fill: statusColors.Critical },
        { status: "Low (26-50%)", count: statusCounts.Low, fill: statusColors.Low },
        { status: "Medium (51-75%)", count: statusCounts.Medium, fill: statusColors.Medium },
        { status: "Healthy (76-100%)", count: statusCounts.Healthy, fill: statusColors.Healthy },
     ];
  }, [devices]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Device Battery Health Overview</CardTitle>
        <CardDescription>A summary of device counts based on their battery level.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              layout="vertical"
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" allowDecimals={false} stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis dataKey="status" type="category" stroke="hsl(var(--muted-foreground))" fontSize={12} width={120} />
              <Tooltip 
                 contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    borderColor: "hsl(var(--border))",
                }}
              />
              <Legend formatter={(value, entry) => <span className="text-muted-foreground">{value}</span>} />
              <Bar dataKey="count" name="Number of Devices" fill="hsl(var(--primary))" >
                {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
