"use client"

import * as React from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import type { DeviceStatus } from "@/types"
import { useIncidents } from "@/lib/incident-context"

const statusColors: Record<DeviceStatus, string> = {
  Operational: "hsl(var(--chart-2))",
  Active_Incident: "hsl(var(--destructive))",
  Maintenance_Required: "hsl(var(--chart-3))",
}

export default function DeviceStatusChart() {
  const { devices } = useIncidents()
  const statusCounts = devices.reduce((acc, device) => {
    acc[device.status] = (acc[device.status] || 0) + 1
    return acc
  }, {} as Record<DeviceStatus, number>)

  const data = Object.entries(statusCounts).map(([name, value]) => ({
    name: name.replace("_", " "),
    value,
    fill: statusColors[name as DeviceStatus],
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Device Status Distribution</CardTitle>
        <CardDescription>A breakdown of the current status of all AEDs in the network.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Tooltip
                cursor={{ fill: "hsl(var(--muted))" }}
                contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    borderColor: "hsl(var(--border))",
                }}
              />
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={120}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
