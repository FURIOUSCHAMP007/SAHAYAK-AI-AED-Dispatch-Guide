"use client"

import * as React from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { useIncidents } from "@/lib/incident-context"

export default function IncidentTypeChart() {
  const { incidents } = useIncidents();

  const chartData = React.useMemo(() => {
     const typeCounts = incidents.reduce((acc, incident) => {
        const type = incident.incidentType || "Unknown";
        acc[type] = (acc[type] || 0) + 1;
        return acc;
     }, {} as Record<string, number>);

     return Object.entries(typeCounts)
        .map(([type, count]) => ({ type, count }))
        .sort((a, b) => b.count - a.count); // Sort by count descending
  }, [incidents]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Incident Type Distribution</CardTitle>
        <CardDescription>A breakdown of the most common types of incidents reported.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              layout="vertical"
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" allowDecimals={false} stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis 
                dataKey="type" 
                type="category" 
                stroke="hsl(var(--muted-foreground))" 
                fontSize={12} 
                width={140}
                interval={0}
               />
              <Tooltip 
                 contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    borderColor: "hsl(var(--border))",
                }}
              />
              <Bar dataKey="count" name="Number of Incidents" fill="hsl(var(--chart-1))" barSize={30} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
