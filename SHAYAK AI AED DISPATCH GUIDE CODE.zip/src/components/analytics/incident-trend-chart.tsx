"use client"

import * as React from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { useIncidents } from "@/lib/incident-context"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { format } from "date-fns"

export default function IncidentTrendChart() {
  const { incidents } = useIncidents()

  const data = React.useMemo(() => {
    const monthlyCounts = incidents.reduce((acc, incident) => {
      const month = format(new Date(incident.timestamp), "yyyy-MM")
      acc[month] = (acc[month] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    return Object.entries(monthlyCounts)
      .map(([month, count]) => ({
        month: format(new Date(month), "MMM yyyy"),
        incidents: count,
      }))
      .sort((a, b) => new Date(a.month).getTime() - new Date(b.month).getTime())
  }, [incidents])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Incident Trends Over Time</CardTitle>
        <CardDescription>A line chart showing the number of incidents recorded per month.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[350px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis allowDecimals={false} stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip 
                contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    borderColor: "hsl(var(--border))",
                }}
              />
              <Legend />
              <Line type="monotone" dataKey="incidents" stroke="hsl(var(--primary))" strokeWidth={2} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
