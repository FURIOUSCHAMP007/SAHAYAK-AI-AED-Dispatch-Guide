"use client"

import * as React from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { format, parseISO } from "date-fns"
import { useIncidents } from "@/lib/incident-context"

export default function MaintenanceHistoryChart() {
  const { devices } = useIncidents()
  const data = React.useMemo(() => {
    const monthlyCounts = devices.reduce((acc, device) => {
      const month = format(parseISO(device.lastMaintenance), "yyyy-MM")
      acc[month] = (acc[month] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    return Object.entries(monthlyCounts)
      .map(([month, count]) => ({
        month: format(parseISO(month), "MMM yyyy"),
        count,
      }))
      .sort((a, b) => new Date(a.month).getTime() - new Date(b.month).getTime())
  }, [devices])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Maintenance Events by Month</CardTitle>
        <CardDescription>Shows the number of devices that received maintenance each month.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[350px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis allowDecimals={false} stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip 
                contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    borderColor: "hsl(var(--border))",
                }}
              />
              <Legend />
              <Bar dataKey="count" name="Devices Serviced" fill="hsl(var(--chart-1))" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
