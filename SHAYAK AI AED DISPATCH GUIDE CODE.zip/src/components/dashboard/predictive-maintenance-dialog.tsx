
"use client"

import * as React from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { predictMaintenanceNeeds, PredictiveMaintenanceOutput } from "@/ai/flows/predictive-maintenance"
import { AEDDevice } from "@/types"
import { AlertCircle, CheckCircle, BrainCircuit, BarChart, FileText, BatteryCharging, List } from "lucide-react"

interface PredictiveMaintenanceDialogProps {
  device: AEDDevice | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function PredictiveMaintenanceDialog({ device, open, onOpenChange }: PredictiveMaintenanceDialogProps) {
  const [prediction, setPrediction] = React.useState<PredictiveMaintenanceOutput | null>(null)
  const [isLoading, setIsLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  React.useEffect(() => {
    if (open && device) {
      // Reset state when dialog is opened
      setPrediction(null)
      setError(null)
      handlePredictiveMaintenance()
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, device])

  const handlePredictiveMaintenance = async () => {
    if (!device) return
    setIsLoading(true)
    setError(null)
    try {
      const result = await predictMaintenanceNeeds({
        deviceId: device.id,
        deviceLogs: device.deviceLogs,
        batteryLevel: device.batteryLevel,
        usagePatterns: device.usagePatterns,
      })
      setPrediction(result)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BrainCircuit className="h-6 w-6 text-primary" />
            Predictive Maintenance Analysis
          </DialogTitle>
          <DialogDescription>
            AI-powered analysis for {device?.name}.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {isLoading && <AnalysisSkeleton />}
          {error && <ErrorAlert message={error} />}
          {prediction && <PredictionResult prediction={prediction} device={device} />}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

const AnalysisSkeleton = () => (
    <div className="space-y-4">
      <Skeleton className="h-8 w-3/4" />
      <div className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
      </div>
       <Skeleton className="h-8 w-1/2" />
       <div className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-4/6" />
      </div>
    </div>
)

const ErrorAlert = ({ message }: { message: string }) => (
    <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Analysis Failed</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
    </Alert>
)

const PredictionResult = ({ prediction, device }: { prediction: PredictiveMaintenanceOutput, device: AEDDevice | null }) => (
    <div>
      <Alert variant={prediction.requiresMaintenance ? 'destructive' : 'default'} className="mb-4">
        {prediction.requiresMaintenance ? <AlertCircle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
        <AlertTitle>{prediction.requiresMaintenance ? 'Maintenance Required' : 'No Maintenance Required'}</AlertTitle>
        <AlertDescription>
          {prediction.predictedMaintenanceType}
        </AlertDescription>
      </Alert>

      <div className="space-y-4 text-sm">
        <div>
          <h3 className="font-semibold text-lg mb-2">Analysis Details</h3>
           <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
             {prediction.explanation.map((point, index) => (
                <li key={index}>{point}</li>
              ))}
           </ul>
        </div>
        
        <p><strong className="text-muted-foreground">Urgency Score:</strong> <span className="font-bold text-primary">{prediction.urgencyScore}/100</span></p>

        <h4 className="font-semibold text-md border-t pt-4 mt-4">Device Data Used</h4>
        <div className="grid grid-cols-2 gap-2 text-muted-foreground">
            <div className="flex items-center gap-2"><BatteryCharging className="h-4 w-4" /> Battery: {device?.batteryLevel}%</div>
            <div className="flex items-center gap-2"><BarChart className="h-4 w-4" /> Usage: {device?.usagePatterns}</div>
            <div className="col-span-2 flex items-start gap-2"><FileText className="h-4 w-4 mt-1" /> Logs: {device?.deviceLogs}</div>
        </div>
      </div>
    </div>
)
