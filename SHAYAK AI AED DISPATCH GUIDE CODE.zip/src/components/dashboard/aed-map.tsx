
"use client";

import * as React from "react";
import Map, { Marker, Popup, NavigationControl } from "react-map-gl/maplibre";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AEDDevice } from "@/types";
import "maplibre-gl/dist/maplibre-gl.css";
import { cn } from "@/lib/utils";
import { HeartPulse, MapPin } from "lucide-react";

interface AedMapProps {
  devices: AEDDevice[];
  onMapClick?: (lngLat: { lat: number; lng: number }) => void;
  incidentLocation?: { lat: number; lng: number } | null;
}

const getPinColor = (status: AEDDevice['status']) => {
    switch(status) {
        case "Operational":
            return "text-green-500";
        case "Active_Incident":
            return "text-red-500";
        case "Maintenance_Required":
            return "text-orange-500";
        default:
            return "text-gray-500";
    }
}

const AedMarker = ({ device, onClick }: { device: AEDDevice, onClick: () => void }) => {
  return (
    <div
      className="cursor-pointer flex items-center justify-center"
      onClick={onClick}
    >
      <HeartPulse className={cn("h-6 w-6 drop-shadow-lg", getPinColor(device.status))} strokeWidth={2.5} />
    </div>
  )
}

const IncidentMarker = ({ location }: { location: { lat: number, lng: number }}) => {
    return (
        <Marker longitude={location.lng} latitude={location.lat} anchor="bottom">
            <MapPin className="h-8 w-8 text-blue-500" fill="currentColor" />
        </Marker>
    );
}

export default function AedMap({ devices, onMapClick, incidentLocation }: AedMapProps) {
  const [popupInfo, setPopupInfo] = React.useState<AEDDevice | null>(null);

  const handleMapClick = (event: maplibregl.MapLayerMouseEvent) => {
    if (onMapClick) {
        onMapClick(event.lngLat);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>AED Location Map</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[500px] w-full rounded-lg overflow-hidden">
          <Map
            initialViewState={{
              longitude: 77.5946,
              latitude: 12.9716,
              zoom: 9
            }}
            mapStyle="https://tiles.stadiamaps.com/styles/alidade_smooth.json"
            style={{ width: '100%', height: '100%' }}
            onClick={handleMapClick}
            cursor="crosshair"
          >
            <NavigationControl position="top-right" />
            {devices.map((device) => (
              <Marker
                key={device.id}
                longitude={device.location.lng}
                latitude={device.location.lat}
                onClick={e => {
                    e.originalEvent.stopPropagation();
                    setPopupInfo(device);
                }}
              >
                <AedMarker device={device} onClick={() => setPopupInfo(device)} />
              </Marker>
            ))}

            {incidentLocation && <IncidentMarker location={incidentLocation} />}

            {popupInfo && (
              <Popup
                anchor="top"
                longitude={popupInfo.location.lng}
                latitude={popupInfo.location.lat}
                onClose={() => setPopupInfo(null)}
                closeOnClick={false}
              >
                <div className="text-sm">
                  <div className="font-bold">{popupInfo.name}</div>
                  <p>{popupInfo.address}</p>
                  <p>Status: <span className="font-semibold">{popupInfo.status.replace('_', ' ')}</span></p>
                </div>
              </Popup>
            )}
          </Map>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
            Map data &copy; <a href="https://www.openstreetmap.org/copyright" className="underline">OpenStreetMap</a> contributors, Imagery &copy; <a href="https://www.mapbox.com/" className="underline">Mapbox</a> | <a href="https://www.maplibre.org/" className="underline">MapLibre</a>
        </p>
      </CardContent>
    </Card>
  );
}
