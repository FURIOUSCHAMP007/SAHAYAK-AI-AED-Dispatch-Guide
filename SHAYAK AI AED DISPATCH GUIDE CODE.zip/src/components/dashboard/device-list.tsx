"use client";

import * as React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { AEDDevice } from "@/types";
import { ArrowUpDown, BrainCircuit } from "lucide-react";
import PredictiveMaintenanceDialog from "./predictive-maintenance-dialog";

interface DeviceListProps {
  devices: AEDDevice[];
}

export default function DeviceList({ devices }: DeviceListProps) {
  const [searchTerm, setSearchTerm] = React.useState("");
  const [sortConfig, setSortConfig] = React.useState<{ key: keyof AEDDevice | null; direction: 'asc' | 'desc' }>({ key: 'name', direction: 'asc' });
  const [selectedDevice, setSelectedDevice] = React.useState<AEDDevice | null>(null);

  const sortedDevices = React.useMemo(() => {
    let sortableItems = [...devices];
    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key!] < b[sortConfig.key!]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key!] > b[sortConfig.key!]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [devices, sortConfig]);

  const filteredDevices = sortedDevices.filter(device =>
    device.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    device.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const requestSort = (key: keyof AEDDevice) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  const getStatusVariant = (status: AEDDevice['status']): "default" | "destructive" | "secondary" | "outline" => {
    switch (status) {
        case "Operational":
            return "default";
        case "Active_Incident":
            return "destructive";
        case "Maintenance_Required":
            return "outline";
        default:
            return "secondary";
    }
  }

  const getStatusColorClass = (status: AEDDevice['status']): string => {
     switch (status) {
        case 'Operational':
          return 'bg-green-500';
        case 'Active_Incident':
          return 'bg-red-500';
        case 'Maintenance_Required':
          return 'bg-orange-500';
        default:
          return 'bg-gray-500';
      }
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>AED Device Fleet</CardTitle>
          <CardDescription>A list of all devices in your network.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Input
              placeholder="Search by name or address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>
                    <Button variant="ghost" onClick={() => requestSort('name')}>
                      Name <ArrowUpDown className="ml-2 h-4 w-4" />
                    </Button>
                  </TableHead>
                  <TableHead>
                    <Button variant="ghost" onClick={() => requestSort('status')}>
                      Status <ArrowUpDown className="ml-2 h-4 w-4" />
                    </Button>
                  </TableHead>
                  <TableHead>
                    <Button variant="ghost" onClick={() => requestSort('batteryLevel')}>
                      Battery <ArrowUpDown className="ml-2 h-4 w-4" />
                    </Button>
                  </TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDevices.map((device) => (
                  <TableRow key={device.id}>
                    <TableCell className="font-medium">{device.name}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusVariant(device.status)}>
                        <span className={`mr-2 h-2 w-2 rounded-full ${getStatusColorClass(device.status)}`}></span>
                        {device.status.replace('_', ' ')}
                      </Badge>
                    </TableCell>
                    <TableCell>{device.batteryLevel}%</TableCell>
                    <TableCell>{device.address}</TableCell>
                    <TableCell className="text-right">
                       <Button variant="outline" size="sm" onClick={() => setSelectedDevice(device)}>
                         <BrainCircuit className="h-4 w-4 mr-2" />
                         Predict
                       </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      {selectedDevice && (
        <PredictiveMaintenanceDialog 
            device={selectedDevice} 
            open={!!selectedDevice}
            onOpenChange={(isOpen) => !isOpen && setSelectedDevice(null)}
        />
      )}
    </>
  );
}
