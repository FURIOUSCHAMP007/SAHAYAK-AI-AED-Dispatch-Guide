"use client";

import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Incident } from "@/types";
import { Siren } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface IncidentFeedProps {
  incidents: Incident[];
}

export default function IncidentFeed({ incidents }: IncidentFeedProps) {

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle>Real-time Incident Feed</CardTitle>
        <CardDescription>New incidents will appear here automatically.</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow p-0">
        <ScrollArea className="h-[450px]">
          <div className="space-y-4 p-6 pt-0">
            {incidents.map((incident) => (
              <div key={incident.id} className="flex items-start gap-4">
                <div className="bg-destructive/10 text-destructive p-2 rounded-full">
                  <Siren className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold">{incident.deviceName}</p>
                  <p className="text-sm text-muted-foreground">{incident.location}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(incident.timestamp), { addSuffix: true })}
                  </p>
                  <Button asChild variant="link" className="p-0 h-auto text-xs mt-1">
                    <Link href={`/incidents/${incident.id}`}>View Details</Link>
                  </Button>
                </div>
              </div>
            ))}
             {incidents.length === 0 && (
                <div className="text-center text-muted-foreground py-10">
                    <p>No active incidents.</p>
                </div>
             )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
