
"use client";

import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { incidents as allIncidents, responders as allResponders, hospitals as allHospitals, incidentTypes } from "@/lib/data";
import { ResponderUnit, Incident, Hospital } from "@/types";
import MapLayout from "./map-layout";
import { List, Ambulance, Eye } from "lucide-react";
import { ScrollArea } from "../ui/scroll-area";
import { Badge } from "../ui/badge";
import { getAIHospitalRecommendation } from "@/ai/flows/get-ai-hospital-recommendation";
import { getDispatchPackage } from "@/ai/flows/get-dispatch-package";
import { findClosestResponder } from "@/lib/dispatch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "../ui/button";

// Constants for simulation
const ON_SCENE_DURATION_MS = 5000; // 5 seconds
const AT_HOSPITAL_DURATION_MS = 5000; // 5 seconds

export default function DispatchDashboard() {
    const [responders, setResponders] = React.useState<ResponderUnit[]>(allResponders);
    const [incidents, setIncidents] = React.useState<Incident[]>(() =>
        allIncidents.map(inc => ({ ...inc, dispatched: false }))
    );
    const [hospitals] = React.useState<Hospital[]>(allHospitals);
    const [showMedBikes, setShowMedBikes] = React.useState(false);

    // Refs to hold the latest state for use in intervals
    const respondersRef = React.useRef(responders);
    const incidentsRef = React.useRef(incidents);
    const hospitalsRef = React.useRef(hospitals);

    React.useEffect(() => {
        respondersRef.current = responders;
    }, [responders]);

    React.useEffect(() => {
        incidentsRef.current = incidents;
    }, [incidents]);

    React.useEffect(() => {
        hospitalsRef.current = hospitals;
    }, [hospitals]);


    const updateResponder = React.useCallback((unitId: string, updates: Partial<ResponderUnit>) => {
        setResponders(prev => {
            const newResponders = prev.map(r => r.id === unitId ? { ...r, ...updates } : r);
            respondersRef.current = newResponders;
            return newResponders;
        });
    }, []);

    const dispatchUnits = React.useCallback(async (incident: Incident) => {
        const incidentTypeInfo = incidentTypes.find(it => it.name === incident.incidentType);
        if (!incidentTypeInfo) {
            console.error(`No incident type info found for ${incident.incidentType}`);
            return;
        }

        let requiredUnits: { unitType: string; quantity: number }[] = [];

        if (incidentTypeInfo.requiresPackage) {
            console.log(`Getting AI dispatch package for ${incident.incidentType}...`);
            const aiPackage = await getDispatchPackage({ incidentType: incident.incidentType });
            requiredUnits = aiPackage.requiredUnits;
        } else {
            requiredUnits = [{ unitType: incidentTypeInfo.recommendedUnit, quantity: 1 }];
        }

        // Safety check: Ensure police are always dispatched
        if (!requiredUnits.some(u => u.unitType === 'Police Car')) {
             requiredUnits.push({ unitType: 'Police Car', quantity: 1 });
        }


        for (const requirement of requiredUnits) {
            for (let i = 0; i < requirement.quantity; i++) {
                // Pass a copy of the current responders to avoid race conditions
                const closestUnit = findClosestResponder(requirement.unitType, [...respondersRef.current], incident);

                if (closestUnit) {
                    console.log(`Dispatching ${closestUnit.id} to incident ${incident.id}`);
                    updateResponder(closestUnit.id, {
                        status: "Enroute to Incident",
                        assignedIncidentId: incident.id
                    });
                } else {
                    console.error(`No available ${requirement.unitType} unit for incident ${incident.id}`);
                    // Break inner loop if no units of this type are available
                    break;
                }
            }
        }

    }, [updateResponder]);

    // Main simulation loop
    React.useEffect(() => {
        const interval = setInterval(async () => {
            // Dispatch units to new incidents
            const undispachedIncidents = incidentsRef.current.filter(i => !i.dispatched);
            for (const incident of undispachedIncidents) {
                await dispatchUnits(incident);
                setIncidents(prev => prev.map(i => i.id === incident.id ? { ...i, dispatched: true } : i));
            }

            for (const unit of respondersRef.current) {
                // Unit arrives at scene
                if (unit.status === 'Enroute to Incident' && unit.eta !== undefined && unit.eta <= 0) {
                    console.log(`Unit ${unit.id} arrived at scene for incident ${unit.assignedIncidentId}`);
                    updateResponder(unit.id, { status: "On Scene", eta: undefined, route: null });

                    // Logic to handle departure from scene after a delay
                    setTimeout(async () => {
                        const currentIncident = incidentsRef.current.find(i => i.id === unit.assignedIncidentId);
                        if (!currentIncident) return;

                        // Only medical units go to the hospital
                        if (unit.unitType.includes('Type') || unit.unitType.includes('Med-Bike')) {
                            console.log(`Unit ${unit.id} is leaving scene, getting hospital recommendation.`);
                            try {
                                const recommendation = await getAIHospitalRecommendation({
                                    incidentType: currentIncident.incidentType,
                                    hospitals: hospitalsRef.current,
                                });

                                const destinationHospital = hospitalsRef.current.find(h => h.id === recommendation.recommendedHospitalId);
                                if (destinationHospital) {
                                    console.log(`Unit ${unit.id} enroute to ${destinationHospital.name}`);
                                    updateResponder(unit.id, { status: 'Enroute to Hospital', destination: destinationHospital.location });
                                }
                            } catch (e) {
                                console.error("Failed to get hospital recommendation, returning to base", e);
                                updateResponder(unit.id, { status: 'Returning to Base', destination: unit.baseLocation, assignedIncidentId: null });
                            }
                        } else {
                            // Non-medical units return to base
                             console.log(`Unit ${unit.id} returning to base.`);
                             updateResponder(unit.id, { status: 'Returning to Base', destination: unit.baseLocation, assignedIncidentId: null });
                        }
                    }, ON_SCENE_DURATION_MS);
                }

                // Unit arrives at hospital
                if (unit.status === 'Enroute to Hospital' && unit.eta !== undefined && unit.eta <= 0) {
                    console.log(`Unit ${unit.id} arrived at hospital.`);
                    updateResponder(unit.id, { status: "At Hospital", eta: undefined, route: null });

                    setTimeout(() => {
                        console.log(`Unit ${unit.id} returning to base.`);
                        updateResponder(unit.id, { status: 'Returning to Base', destination: unit.baseLocation, assignedIncidentId: null });
                    }, AT_HOSPITAL_DURATION_MS);
                }

                // Unit arrives back at base
                if (unit.status === 'Returning to Base' && unit.eta !== undefined && unit.eta <= 0) {
                    console.log(`Unit ${unit.id} is back at base and available.`);
                    updateResponder(unit.id, { status: 'Available', route: null, eta: undefined, destination: undefined, distanceTraveled: 0 });
                }
            }
        }, 2000); // Check status every 2 seconds

        return () => clearInterval(interval);
    }, [dispatchUnits, updateResponder]);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[calc(100vh-100px)]">
            <div className="lg:col-span-2 h-full">
                <MapLayout
                    responders={responders}
                    incidents={incidents}
                    hospitals={hospitals}
                    setResponders={setResponders}
                />
            </div>
            <div className="h-full flex flex-col">
                <Tabs defaultValue="incidents" className="flex-1 flex flex-col">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="incidents">
                            <List className="mr-2" />
                            Incidents
                        </TabsTrigger>
                        <TabsTrigger value="responders">
                            <Ambulance className="mr-2" />
                            Responders
                        </TabsTrigger>
                    </TabsList>
                    <TabsContent value="incidents" className="flex-1 overflow-hidden">
                        <Card className="h-full flex flex-col">
                            <CardHeader>
                                <CardTitle>All Incidents</CardTitle>
                            </CardHeader>
                            <CardContent className="flex-1 overflow-hidden p-0">
                                <ScrollArea className="h-full">
                                    <div className="p-4 space-y-4">
                                        {incidents.map(incident => (
                                            <div key={incident.id} className="p-3 rounded-lg border bg-muted/50">
                                                <p className="font-semibold">{incident.incidentType}</p>
                                                <p className="text-sm text-muted-foreground">{incident.location}</p>
                                                <p className="text-xs text-muted-foreground">{new Date(incident.timestamp).toLocaleString()}</p>
                                            </div>
                                        ))}
                                    </div>
                                </ScrollArea>
                            </CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="responders" className="flex-1 overflow-hidden">
                        <Card className="h-full flex flex-col">
                            <CardHeader className="flex flex-row items-center justify-between">
                                <CardTitle>Responder Units</CardTitle>
                                <Button variant="outline" size="sm" onClick={() => setShowMedBikes(s => !s)}>
                                    <Eye className="mr-2 h-4 w-4" />
                                    {showMedBikes ? "Hide" : "Show"} Med-Bikes
                                </Button>
                            </CardHeader>
                            <CardContent className="flex-1 overflow-hidden p-0">
                                <ScrollArea className="h-full">
                                    <div className="p-4 space-y-2">
                                        {responders
                                            .filter(u => showMedBikes || u.unitType !== 'Med-Bike')
                                            .map(unit => (
                                            <div key={unit.id} className="p-3 rounded-md border text-sm">
                                                <div className="flex justify-between items-center">
                                                    <p className="font-bold">{unit.id}</p>
                                                    <Badge variant={unit.status === 'Available' ? 'default' : unit.status === "On Scene" || unit.status === "At Hospital" ? "secondary" : "outline"}>
                                                        {unit.status}
                                                    </Badge>
                                                </div>
                                                <p className="text-muted-foreground">{unit.unitType}</p>
                                                {unit.eta !== undefined && unit.eta > 0 && <p className="text-xs text-blue-500 font-semibold">ETA: {unit.eta.toFixed(1)} min</p>}
                                                {unit.assignedIncidentId && <p className="text-xs text-amber-600">To Incident: {incidents.find(i=> i.id === unit.assignedIncidentId)?.incidentType || unit.assignedIncidentId}</p>}
                                            </div>
                                        ))}
                                    </div>
                                </ScrollArea>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}
