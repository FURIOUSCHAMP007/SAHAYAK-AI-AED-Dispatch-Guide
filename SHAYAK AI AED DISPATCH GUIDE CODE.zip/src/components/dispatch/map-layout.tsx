

"use client";

import * as React from "react";
import Map, { Marker, Popup, NavigationControl, Source, Layer, useMap } from "react-map-gl/maplibre";
import { Card, CardContent } from "@/components/ui/card";
import { ResponderUnit, Incident, Hospital } from "@/types";
import "maplibre-gl/dist/maplibre-gl.css";
import { cn } from "@/lib/utils";
import { Ambulance, Shield, HospitalIcon, Siren, Users, Bike } from "lucide-react";
import { lineString as makeLineString } from '@turf/helpers';
import lineDistance from '@turf/length';
import along from '@turf/along';

// SIMULATION CONSTANTS
const SIMULATION_SPEED = 200; // km/h
const UPDATE_INTERVAL = 100; // ms

interface MapLayoutProps {
  responders: ResponderUnit[];
  incidents: Incident[];
  hospitals: Hospital[];
  setResponders: React.Dispatch<React.SetStateAction<ResponderUnit[]>>;
}

const statusColors: Record<ResponderUnit['status'], string> = {
    Available: "text-green-500",
    "Enroute to Incident": "text-yellow-500",
    "On Scene": "text-blue-500",
    "Enroute to Hospital": "text-purple-500",
    "Returning to Base": "text-gray-500",
    "Out of Service": "text-red-500",
    "At Hospital": "text-cyan-500",
};

const routeLayer: maplibregl.LineLayerSpecification = {
    id: 'route',
    type: 'line',
    source: 'route',
    layout: {
        'line-join': 'round',
        'line-cap': 'round'
    },
    paint: {
        'line-color': '#888',
        'line-opacity': 0.6,
        'line-width': 4
    }
};

const UnitMarker = ({ unit }: { unit: ResponderUnit }) => {
    let Icon;
    if (unit.unitType.includes('Police')) {
        Icon = Shield;
    } else if (unit.unitType.includes('Social Service')) {
        Icon = Users;
    } else if (unit.unitType.includes('Med-Bike')) {
        Icon = Bike;
    }
    else {
        Icon = Ambulance;
    }
    
    return (
        <div className="cursor-pointer flex flex-col items-center">
           <Icon className={cn("h-7 w-7 drop-shadow-lg", statusColors[unit.status])} strokeWidth={2} />
           <div className="text-xs font-bold bg-background/80 px-1 rounded-sm text-center">
                <span>{unit.id}</span>
                {unit.eta !== undefined && <span className="block text-blue-500">{unit.eta.toFixed(0)} min</span>}
           </div>
        </div>
    )
}

const IncidentMarker = ({ incident }: { incident: Incident }) => {
    return (
        <div className="cursor-pointer flex flex-col items-center">
            <Siren className="h-8 w-8 text-red-600 animate-pulse" />
            <span className="text-xs font-semibold bg-red-500/80 text-white px-1 rounded-sm">{incident.incidentType}</span>
        </div>
    )
}

const HospitalMarker = ({ hospital }: { hospital: Hospital }) => {
    return (
         <div className="cursor-pointer flex flex-col items-center">
            <HospitalIcon className="h-7 w-7 text-blue-700" />
            <span className="text-xs font-semibold bg-background/80 px-1 rounded-sm">{hospital.name}</span>
        </div>
    )
}

function MapUpdater({ responders, setResponders, incidents }: { 
    responders: ResponderUnit[]; 
    setResponders: React.Dispatch<React.SetStateAction<ResponderUnit[]>>;
    incidents: Incident[];
}) {
    const { current: map } = useMap();
    const respondersRef = React.useRef(responders);

    React.useEffect(() => {
        respondersRef.current = responders;
    }, [responders]);

    const updateRoute = React.useCallback(async (unitId: string, start: { lat: number, lng: number }, end: { lat: number, lng: number }) => {
        const url = `https://routing.openstreetmap.de/routed-car/route/v1/driving/${start.lng},${start.lat};${end.lng},${end.lat}?overview=full&geometries=geojson`;
        try {
            const response = await fetch(url);
            const data = await response.json();
            if (data.routes && data.routes.length > 0) {
                const route = data.routes[0].geometry;
                const durationMinutes = data.routes[0].duration / 60;
                setResponders(prev => prev.map(r => r.id === unitId ? { ...r, route, eta: durationMinutes, lastUpdate: Date.now(), distanceTraveled: 0 } : r));
            }
        } catch (error) {
            console.error("Error fetching route:", error);
        }
    }, [setResponders]);

    // Effect to fetch routes for newly dispatched units
    React.useEffect(() => {
        responders.forEach(unit => {
            if (!unit.route) {
                if (unit.status === 'Enroute to Incident') {
                    const incident = incidents.find(i => i.id === unit.assignedIncidentId);
                    if (incident && incident.lat && incident.lng) {
                        updateRoute(unit.id, unit.currentLocation, { lat: incident.lat, lng: incident.lng });
                    }
                } else if ((unit.status === 'Enroute to Hospital' || unit.status === 'Returning to Base') && unit.destination) {
                    updateRoute(unit.id, unit.currentLocation, unit.destination);
                }
            }
        });
    }, [responders, incidents, updateRoute]);

    // Effect for movement simulation
    React.useEffect(() => {
        const intervalId = setInterval(() => {
            const now = Date.now();
            setResponders(currentResponders => 
                currentResponders.map(unit => {
                    if (unit.route && unit.lastUpdate && (unit.status === 'Enroute to Incident' || unit.status === 'Enroute to Hospital' || unit.status === 'Returning to Base')) {
                        const timeElapsedSeconds = (now - unit.lastUpdate) / 1000;
                        const distanceToTravel = (SIMULATION_SPEED / 3600) * timeElapsedSeconds; // in km

                        const line = makeLineString(unit.route.coordinates);
                        const totalDistance = lineDistance(line, { units: 'kilometers' });

                        const currentDistance = unit.distanceTraveled || 0;
                        const newDistance = currentDistance + distanceToTravel;

                        if (newDistance >= totalDistance) {
                            const finalCoords = unit.route.coordinates[unit.route.coordinates.length - 1];
                            return { 
                                ...unit, 
                                currentLocation: { lat: finalCoords[1], lng: finalCoords[0] }, 
                                distanceTraveled: totalDistance, 
                                eta: 0 
                            };
                        } else {
                            const newPoint = along(line, newDistance, { units: 'kilometers' });
                            const newCoords = newPoint.geometry.coordinates;
                            const remainingEta = unit.eta ? unit.eta - (timeElapsedSeconds / 60) : 0;
                            return { 
                                ...unit, 
                                currentLocation: { lat: newCoords[1], lng: newCoords[0] }, 
                                distanceTraveled: newDistance, 
                                lastUpdate: now, 
                                eta: Math.max(0, remainingEta) 
                            };
                        }
                    }
                    return unit;
                })
            );
        }, UPDATE_INTERVAL);

        return () => clearInterval(intervalId);
    }, [setResponders]);

    return null;
}


export default function MapLayout({ responders, incidents, hospitals, setResponders }: MapLayoutProps) {
  const [popupInfo, setPopupInfo] = React.useState<ResponderUnit | Incident | Hospital | null>(null);

  const getCoordinates = (item: ResponderUnit | Incident | Hospital): { lat: number; lng: number } | null => {
    if ('currentLocation' in item && item.currentLocation) { // ResponderUnit
        return item.currentLocation;
    }
    if ('location' in item && typeof item.location === 'object' && item.location && 'lat' in item.location && 'lng' in item.location) { // Hospital
        return item.location;
    }
    if ('lat' in item && 'lng' in item && typeof item.lat === 'number' && typeof item.lng === 'number') { // Incident
        return { lat: item.lat, lng: item.lng };
    }
    return null;
}
  
  const allRoutes = React.useMemo(() => {
     const features = responders
            .filter(r => r.route)
            .map(r => ({
                type: 'Feature',
                geometry: r.route,
                properties: { id: r.id }
            }));
      return {
          type: 'FeatureCollection',
          features: features
      };
  }, [responders]);

  return (
    <Card className="h-full">
      <CardContent className="h-full w-full p-0 rounded-lg overflow-hidden">
        <Map
          initialViewState={{
            longitude: 77.5946,
            latitude: 12.9716,
            zoom: 11
          }}
          mapStyle="https://tiles.stadiamaps.com/styles/alidade_smooth.json"
          style={{ width: '100%', height: '100%' }}
        >
          <MapUpdater responders={responders} setResponders={setResponders} incidents={incidents} />
          <NavigationControl position="top-right" />
          
          <Source id="routes-source" type="geojson" data={allRoutes}>
             <Layer {...routeLayer} />
          </Source>

          {responders.map((unit) => (
            <Marker
              key={`unit-${unit.id}`}
              longitude={unit.currentLocation.lng}
              latitude={unit.currentLocation.lat}
              onClick={e => {
                  e.originalEvent.stopPropagation();
                  setPopupInfo(unit);
              }}
            >
              <UnitMarker unit={unit} />
            </Marker>
          ))}

          {incidents.map((incident) => {
            const coords = getCoordinates(incident);
            return coords ? (
                <Marker
                    key={`incident-${incident.id}`}
                    longitude={coords.lng}
                    latitude={coords.lat}
                     onClick={e => {
                        e.originalEvent.stopPropagation();
                        setPopupInfo(incident);
                    }}
                >
                    <IncidentMarker incident={incident} />
                </Marker>
            ) : null;
          })}

          {hospitals.map((hospital) => (
            <Marker
                key={`hospital-${hospital.id}`}
                longitude={hospital.location.lng}
                latitude={hospital.location.lat}
                onClick={e => {
                    e.originalEvent.stopPropagation();
                    setPopupInfo(hospital);
                }}
            >
                <HospitalMarker hospital={hospital} />
            </Marker>
          ))}

          {popupInfo && getCoordinates(popupInfo) && (
            <Popup
              anchor="top"
              longitude={getCoordinates(popupInfo)!.lng}
              latitude={getCoordinates(popupInfo)!.lat}
              onClose={() => setPopupInfo(null)}
              closeOnClick={false}
              offset={40}
            >
              <div className="text-sm max-w-xs">
                {'unitType' in popupInfo && <div className="font-bold">{popupInfo.id} - {popupInfo.unitType}</div>}
                {'incidentType' in popupInfo && <div className="font-bold">{popupInfo.incidentType}</div>}
                {'specialties' in popupInfo && <div className="font-bold">{popupInfo.name}</div>}
                <p>{'status' in popupInfo ? `Status: ${popupInfo.status}` : 'address' in popupInfo ? popupInfo.address : `Location: ${getCoordinates(popupInfo)?.lat.toFixed(4)}, ${getCoordinates(popupInfo)?.lng.toFixed(4)}`}</p>
                 {'assignedIncidentId' in popupInfo && popupInfo.assignedIncidentId && <p>To Incident: {incidents.find(i=> i.id === popupInfo.assignedIncidentId)?.incidentType || popupInfo.assignedIncidentId}</p>}
              </div>
            </Popup>
          )}
        </Map>
      </CardContent>
    </Card>
  );
}
