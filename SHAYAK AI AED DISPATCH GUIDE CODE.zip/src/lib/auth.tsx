"use client";

import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Skeleton } from '@/components/ui/skeleton';

interface AuthContextType {
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Simulate checking for a token in localStorage
    try {
      const storedAuth = localStorage.getItem('sahayak_auth');
      if (storedAuth === 'true') {
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.error("Could not access localStorage:", error);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated && pathname !== '/login') {
        router.push('/login');
      } else if (isAuthenticated && pathname === '/login') {
        router.push('/');
      }
    }
  }, [isAuthenticated, isLoading, pathname, router]);


  const login = async (email: string, pass: string) => {
    // In a real app, you'd call Firebase here.
    // For this mock, we'll just simulate a successful login.
    console.log(`Attempting login with email: ${email}`);
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    try {
        localStorage.setItem('sahayak_auth', 'true');
    } catch (error) {
        console.error("Could not access localStorage:", error);
    }
    setIsAuthenticated(true);
    setIsLoading(false);
    router.push('/');
  };

  const logout = () => {
    setIsLoading(true);
    try {
        localStorage.removeItem('sahayak_auth');
    } catch (error) {
        console.error("Could not access localStorage:", error);
    }
    setIsAuthenticated(false);
    setIsLoading(false);
    router.push('/login');
  };

  const value = { isAuthenticated, login, logout, isLoading };
  
  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="w-full max-w-md space-y-4 p-4">
           <Skeleton className="h-8 w-1/2 mx-auto" />
           <Skeleton className="h-10 w-full" />
           <Skeleton className="h-10 w-full" />
           <Skeleton className="h-12 w-full" />
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
