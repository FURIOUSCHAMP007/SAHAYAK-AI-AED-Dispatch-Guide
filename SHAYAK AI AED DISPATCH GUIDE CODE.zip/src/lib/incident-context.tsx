
"use client"

import React, { createContext, useContext, useState, ReactNode } from 'react';
import type { Incident, AEDDevice } from '@/types';
import { incidents as initialIncidents, devices as initialDevices } from '@/lib/data';
import { ReportIncidentOutput, TriageIncidentOutput } from '@/ai/schemas/incident-report';

interface IncidentContextType {
  incidents: Incident[];
  addIncident: (newIncident: ReportIncidentOutput, triageResult: TriageIncidentOutput) => void;
  devices: AEDDevice[];
  updateDeviceStatus: (deviceId: string, status: AEDDevice['status']) => void;
}

const IncidentContext = createContext<IncidentContextType | undefined>(undefined);

// Export initial incidents for server-side usage
export const incidents = initialIncidents;

export function IncidentProvider({ children }: { children: ReactNode }) {
  const [incidents, setIncidents] = useState<Incident[]>(initialIncidents);
  const [devices, setDevices] = useState<AEDDevice[]>(initialDevices);

  const addIncident = (newIncidentData: ReportIncidentOutput, triageResult: TriageIncidentOutput) => {
    // A simple approach to geocoding for the demo.
    // In a real app, this would be a call to a service like Google Maps Geocoding API.
    const geocode = (address: string): { lat: number; lng: number } | null => {
        const locations: Record<string, { lat: number; lng: number }> = {
            "cubbon park": { lat: 12.9757, lng: 77.5929 },
            "devanahalli": { lat: 13.2359, lng: 77.7018 },
            "hoskote": { lat: 13.0725, lng: 77.7954 },
            "whitefield": { lat: 12.9698, lng: 77.7499 },
            "koramangala": { lat: 12.9351, lng: 77.6245 },
        };

        const lowerCaseAddress = address.toLowerCase();
        for (const place in locations) {
            if (lowerCaseAddress.includes(place)) {
                return locations[place];
            }
        }
        
        const latLng = address.split(',').map(s => parseFloat(s.trim()));
        if (latLng.length === 2 && !isNaN(latLng[0]) && !isNaN(latLng[1])) {
            return { lat: latLng[0], lng: latLng[1] };
        }

        return { lat: 12.9716, lng: 77.5946 }; // Bangalore center
    };

    const incidentLocation = geocode(newIncidentData.location);

    const newIncident: Incident = {
        id: newIncidentData.incidentId,
        deviceId: newIncidentData.deviceId || 'N/A',
        deviceName: newIncidentData.deviceName || 'N/A',
        location: newIncidentData.location,
        timestamp: newIncidentData.timestamp,
        incidentType: triageResult.incidentType,
        patientData: newIncidentData.patientData,
        eventLog: newIncidentData.eventLog,
        ecgDataUrl: "https://placehold.co/800x200/2C3E50/F0F4F8.png?text=ECG+Data",
        ecgInsights: newIncidentData.ecgInsights,
        timeline: newIncidentData.timeline,
        lat: incidentLocation?.lat,
        lng: incidentLocation?.lng,
    };

    setIncidents(prevIncidents => [newIncident, ...prevIncidents]);
    
    // If a device was assigned, update its status
    if (newIncidentData.deviceId) {
        updateDeviceStatus(newIncidentData.deviceId, 'Active_Incident');
    }
  };

  const updateDeviceStatus = (deviceId: string, status: AEDDevice['status']) => {
    setDevices(prevDevices => 
        prevDevices.map(device => 
            device.id === deviceId ? { ...device, status } : device
        )
    );
  };

  const value = { incidents, addIncident, devices, updateDeviceStatus };

  return (
    <IncidentContext.Provider value={value}>
      {children}
    </IncidentContext.Provider>
  );
}

export function useIncidents() {
  const context = useContext(IncidentContext);
  if (context === undefined) {
    throw new Error('useIncidents must be used within an IncidentProvider');
  }
  return context;
}
