/**
 * @fileOverview Dispatch logic for finding the nearest available AED and responders.
 */
import type { ResponderUnit, Incident } from "@/types";

// A simple approach to geocoding for the demo.
// In a real app, this would be a call to a service like Google Maps Geocoding API.
const geocode = async (address: string): Promise<{ lat: number; lng: number } | null> => {
    // This is a very simple mock. It won't be accurate.
    // It checks if a known city/area is in the address string.
    const locations: Record<string, { lat: number; lng: number }> = {
        "cubbon park": { lat: 12.9757, lng: 77.5929 },
        "devanahalli": { lat: 13.2359, lng: 77.7018 },
        "hoskote": { lat: 13.0725, lng: 77.7954 },
        "whitefield": { lat: 12.9698, lng: 77.7499 },
        "koramangala": { lat: 12.9351, lng: 77.6245 },
    };

    const lowerCaseAddress = address.toLowerCase();
    for (const place in locations) {
        if (lowerCaseAddress.includes(place)) {
            return locations[place];
        }
    }
    
    // Default fallback if no known location is found
    return { lat: 12.9716, lng: 77.5946 }; // Bangalore center
};


// Haversine formula to calculate distance between two lat/lng points
const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
};

export const findNearestDevice = async (location: string) => {
    // Note: In a real application, the list of devices would be fetched from a database.
    // For this prototype, we are importing it from the static data file.
    const { devices } = await import('@/lib/data');

    const incidentLocation = await geocode(location);
    if (!incidentLocation) {
        return null;
    }

    const availableDevices = devices.filter(d => d.status === 'Operational');

    if (availableDevices.length === 0) {
        return null;
    }

    let closestDevice = null;
    let minDistance = Infinity;

    for (const device of availableDevices) {
        const distance = getDistance(
            incidentLocation.lat,
            incidentLocation.lng,
            device.location.lat,
            device.location.lng
        );

        if (distance < minDistance) {
            minDistance = distance;
            closestDevice = device;
        }
    }

    if (!closestDevice) return null;

    return {
        id: closestDevice.id,
        name: closestDevice.name,
        address: closestDevice.address,
    };
};


export const findClosestResponder = (unitType: string, responders: ResponderUnit[], incident: Incident) => {
    if (!incident.lat || !incident.lng) return null;

    const availableResponders = responders.filter(r => r.status === 'Available' && r.unitType === unitType);

    if (availableResponders.length === 0) {
        return null;
    }

    let closestUnit = null;
    let minDistance = Infinity;

    for (const unit of availableResponders) {
        const distance = getDistance(
            incident.lat,
            incident.lng,
            unit.currentLocation.lat,
            unit.currentLocation.lng
        );

        if (distance < minDistance) {
            minDistance = distance;
            closestUnit = unit;
        }
    }

    return closestUnit;
}
