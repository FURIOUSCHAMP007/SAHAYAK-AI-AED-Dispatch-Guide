# SAHAYAK Project: Research & Development Considerations

This document outlines the key research domains required to transition the SAHAYAK prototype into a production-ready, real-world system. While this prototype demonstrates core functionalities, a production-grade medical device system necessitates rigorous investigation and validation across multiple disciplines to ensure safety, efficacy, and reliability.

---

### 1. Medical and Clinical Research

The clinical validity and safety of the system are paramount. Research in this area ensures that the guidance and analysis provided are aligned with established medical best practices.

*   **CPR & AED Best Practices:** The core instructional guides must be meticulously aligned with the latest guidelines from official bodies like the **American Heart Association (AHA)** or the **International Liaison Committee on Resuscitation (ILCOR)**. This includes precise details on compression rate (100-120 per minute), depth, hand placement, and protocols for diverse patient demographics (adult, child, male, female). The current scripts serve as a baseline and require validation by certified medical professionals.

*   **ECG Analysis Algorithms:** The "AI Brain" for ECG analysis represents a significant research and development effort. It would require access to large, annotated datasets of real ECG rhythm strips to train a machine learning model capable of accurately distinguishing between shockable rhythms (e.g., Ventricular Fibrillation) and non-shockable rhythms (e.g., Asystole). This is a specialized field of medical signal processing that demands high accuracy and reliability.

*   **Human Factors in Emergency Response:** Extensive research into human-computer interaction (HCI) under extreme stress is crucial. The UI/UX of the application, the clarity of audio instructions, and the design of visual guides must be rigorously tested with lay responders in simulated emergency scenarios. The goal is to ensure the system reduces cognitive load and user error, thereby maximizing the effectiveness of the response.

### 2. Technical and AI Research

The robustness and accuracy of the AI models and underlying technology are critical for the system's performance.

*   **Predictive Maintenance Models:** To accurately predict device failure, a machine learning model must be trained on historical data from a large fleet of real-world AEDs. This involves analyzing battery degradation curves, correlating device self-test error codes with actual component failures, and understanding how usage patterns impact device longevity.

*   **Natural Language Processing (NLP) for Dispatch:** The "Report Incident" feature relies on NLP to structure a caller's report. A production system would require advanced techniques like **Named Entity Recognition (NER)** to reliably extract critical information (addresses, patient conditions, timelines) from unstructured, often frantic, verbal communication. The model would need to be trained on a diverse dataset of emergency call transcripts.

*   **Text-to-Speech (TTS) Voice & Delivery:** Research is required to select a TTS voice that is not only clear but also has a calming yet authoritative tone. The pacing, intonation, and diction are critical when delivering life-saving instructions. A/B testing with different voices and delivery styles in simulated environments would be necessary to find the most effective configuration.

### 3. Regulatory and Compliance Research

Navigating the regulatory landscape is a non-negotiable aspect of developing a medical device.

*   **Medical Device Classification & Approval:** A system like SAHAYAK would likely be classified as **Software as a Medical Device (SaMD)**. This subjects it to a rigorous approval process from regulatory bodies such as the **FDA** (in the United States), **EMA** (in Europe), or other national health authorities. This process involves extensive documentation of the design, development, testing, and quality management processes.

*   **Data Privacy and Security:** The system handles Protected Health Information (PHI) and is therefore subject to strict privacy and security regulations like **HIPAA** (in the US) or **GDPR** (in Europe). All data—at rest and in transit—must be heavily encrypted, and access controls must be stringently enforced to protect patient confidentiality. A thorough security audit and a Data Protection Impact Assessment (DPIA) would be mandatory.

### 4. Sustainable Development Goal (SDG) Alignment

The SAHAYAK project directly contributes to the United Nations Sustainable Development Goals (SDGs), aligning its real-world impact with global strategic objectives.

*   **SDG 3: Good Health and Well-being:** This is the project's primary alignment. By facilitating rapid public access to defibrillation and improving the quality of bystander CPR, SAHAYAK directly addresses **Target 3.4**, which aims to reduce premature mortality from non-communicable diseases like sudden cardiac arrest. It also strengthens community capacity for managing acute health risks, aligning with **Target 3.d**.

*   **SDG 9: Industry, Innovation, and Infrastructure:** The project is an example of leveraging innovative technology (AI, IoT) to build a resilient, intelligent public health infrastructure. The network of managed AEDs contributes to **Target 9.1** by developing quality and reliable infrastructure that enhances human well-being.

*   **SDG 11: Sustainable Cities and Communities:** A key aspect of this goal is making communities and cities safer and more resilient. By improving emergency response capabilities for cardiac arrest, SAHAYAK directly contributes to **Target 11.5**, which aims to significantly reduce deaths and protect the vulnerable in disaster situations, including medical emergencies.

---

### 5. Full Dispatch Logic Overview

This section provides a comprehensive overview of the entire dispatch logic, from the moment an incident is created to the point where units are moving on the map. It's a sophisticated process that blends AI recommendations with fallback procedures and real-time simulation.

Here is the step-by-step breakdown of the full dispatch logic:

**Trigger:** The process begins in the `createNewIncident` function within `src/components/dispatch-dashboard.tsx` when a dispatcher confirms a new incident.

**Data Check:** The system immediately looks up the confirmed `incidentType` in the `incidentTypes` data located in `src/lib/data.ts`. This data contains crucial information, including the `recommendedUnit` for that incident and whether it `requiresPackage` (a multi-unit response).

This is where the logic splits based on the incident's complexity:

*   **If `requiresPackage` is true (for complex incidents like a "Mass Casualty Incident"):**
    *   An AI call is made to the `getDispatchPackage` flow.
    *   This AI analyzes the incident type and returns an optimal list of required units and quantities (e.g., `[{ unitType: 'Type F (Disaster)', quantity: 1 }, { unitType: 'Type C (ALS)', quantity: 2 }]`).
    *   This list becomes the dispatch requirement.
*   **If `requiresPackage` is false (for standard incidents):**
    *   The system simply uses the `recommendedUnit` from the `incidentTypes` data.
    *   The dispatch requirement is set to a quantity of one of that specific unit (e.g., `[{ unitType: 'Type C (ALS)', quantity: 1 }]`).

After the initial dispatch package is determined (either by AI or by the standard recommendation), a critical safety check occurs:

1.  The system checks if a "Police Car" is already included in the list of required units.
2.  If not, it automatically adds `{ unitType: 'Police Car', quantity: 1 }` to the dispatch requirements. This ensures a police presence at every scene.

With the final list of required units, the system iterates through each requirement:

1.  It filters the main `responders` list to find all units that are `Available` and match the required `unitType`.
2.  From that filtered list, it uses the `findClosestResponder` function to pinpoint the geographically nearest unit to the incident's location.
3.  The selected unit's status is changed from `Available` to `Enroute to Incident`, and it is assigned the `incidentId`.
4.  If no matching unit is available, an error is logged, and the system moves to the next requirement.

This is where the `MapLayout` component takes over:

*   **Route Calculation:** Immediately after a unit is assigned, the `updateRoute` function is called. It uses the OSRM (Open Source Routing Machine) API to fetch a detailed GeoJSON route from the unit's current position to the incident location.
*   **ETA Display:** The route duration from the API is used to calculate and display a real-time ETA next to the unit on the map.
*   **Movement Simulation:** A `setInterval` loop in `src/components/map-layout.tsx` runs every 100 milliseconds. In each "tick":
    *   It checks the responder's current route and position.
    *   It calculates how far the unit should have moved since the last tick based on the `SIMULATION_SPEED`.
    *   It updates the unit's latitude and longitude, moving it along the pre-calculated route path.

The simulation doesn't stop once a unit reaches the scene. The logic handles the entire lifecycle of a responder:

*   **Arrival at Scene:** When a unit reaches the end of its route, its status changes to `On Scene`.
*   **Hospital Transport:** After a short, simulated delay, the system determines the next destination. It calls the `getAIHospitalRecommendation` flow, which considers the incident type, traffic, and hospital capabilities to choose the best hospital. A new route is calculated, and the unit's status changes to `Enroute to Hospital`.
*   **Return to Base:** After another simulated delay at the hospital, a final route is calculated back to the unit's home `baseLocation`, and its status becomes `Returning to Base`.
*   **Ready for Next Call:** Upon reaching its base, the unit's status is reset to `Available`, its route is cleared, and it becomes ready for the next dispatch.

---

### Appendix: System Test Case Scenarios

This appendix outlines 25 test case scenarios designed to validate the functionality and AI-driven logic of the SAHAYAK system.

**Category 1: Standard Medical Emergencies**

*   **Case 1.1:** **Clear Cardiac Arrest.** Caller reports: "A man just collapsed! He's not breathing!" *Expected Outcome:* AI classifies as "Cardiac Arrest," finds nearest AED, generates a structured report.
*   **Case 1.2:** **Ambiguous Chest Pain.** Caller reports: "My father is complaining of a bad pain in his chest and his arm hurts." *Expected Outcome:* AI classifies as "Chest Pain," suggests critical questions about breathing and consciousness, finds nearest AED.
*   **Case 1.3:** **Breathing Difficulty.** Caller reports: "My friend can't catch her breath, she's turning blue!" *Expected Outcome:* AI classifies as "Breathing Problem," provides high confidence score.
*   **Case 1.4:** **Simple Faint.** Caller reports: "Someone just fainted in the queue, but they seem to be waking up now." *Expected Outcome:* AI classifies as "Unconscious / Fainting," provides a lower confidence score for cardiac arrest, finds nearest AED as a precaution.
*   **Case 1.5:** **Active Seizure.** Caller reports: "There's a person shaking uncontrollably on the ground." *Expected Outcome:* AI classifies as "Seizure," provides critical questions about head injury and duration.
*   **Case 1.6:** **Fall with Injury.** Caller reports: "An elderly woman fell and she's bleeding from her head." *Expected Outcome:* AI classifies as "Fall / Injury," prompts with questions about consciousness.
*   **Case 1.7:** **Unknown Medical.** Caller is frantic: "Help! Something is wrong with my mother, I don't know what's happening!" *Expected Outcome:* AI classifies as "Other Medical," critical questions focus on breathing and consciousness.

**Category 2: Scenarios Requiring Police Dispatch**

*   **Case 2.1:** **Assault Leading to Injury.** Caller reports: "Two guys were fighting and one of them is on the ground, not moving!" *Expected Outcome:* AI dispatches AED and **uses the `notifyPolice` tool**, citing "public disturbance/assault."
*   **Case 2.2:** **Car Accident.** Caller reports: "There's been a bad car crash, and one driver is slumped over the wheel." *Expected Outcome:* AI dispatches AED and **uses the `notifyPolice` tool**, citing "motor vehicle accident."
*   **Case 2.3:** **Suspicious Circumstances.** Caller reports: "I heard a loud noise and now my neighbor is lying in his front yard. I'm scared to go outside." *Expected Outcome:* AI dispatches AED and **uses `notifyPolice` tool**, citing "potential crime scene."
*   **Case 2.4:** **Public Disturbance.** Caller reports: "A man was shouting and breaking things in the park, and now he's collapsed." *Expected Outcome:* AI dispatches AED and **uses `notifyPolice` tool** for scene safety.

**Category 3: Scenarios Requiring Social Services Dispatch**

*   **Case 3.1:** **Vulnerable Person.** Caller reports: "There is a man who sleeps in the park who looks very sick and isn't responding." *Expected Outcome:* AI dispatches AED and **uses the `notifySocialServices` tool**, citing "vulnerable homeless individual."
*   **Case 3.2:** **Mental Health Crisis.** Caller reports: "My sister is having a severe panic attack and has fainted. She has a history of mental health issues." *Expected Outcome:* AI dispatches AED and **uses `notifySocialServices` tool** for mental health support.
*   **Case 3.3:** **Elderly Neglect Concern.** Caller reports: "I'm checking on my elderly neighbor and he's on the floor, very weak. He lives alone and I don't think he's been eating." *Expected Outcome:* AI dispatches AED and **uses `notifySocialServices` tool** for a welfare check.
*   **Case 3.4:** **Unattended Child.** Caller reports: "There's a child who seems to have fainted on the playground, and I can't find their parents." *Expected Outcome:* AI dispatches AED, **uses `notifyPolice` tool** (for missing parents) and **`notifySocialServices` tool** (for child welfare).

**Category 4: Complex & Edge Case Scenarios**

*   **Case 4.1:** **No Device Available.** The incident location is far from any operational AED. *Expected Outcome:* AI report indicates no device could be assigned. The system still generates an incident report for manual dispatch.
*   **Case 4.2:** **Vague Location.** Caller reports: "Someone collapsed on the jogging trail in Cubbon Park, near the big tree." *Expected Outcome:* The `findNearestDevice` tool uses the geocoded location for "Cubbon Park" and finds the closest device to the park's center.
*   **Case 4.3:** **Language Barrier.** Caller's report is in broken English with key terms like "heart" and "no breath." *Expected Outcome:* AI successfully identifies keywords and classifies as "Cardiac Arrest".
*   **Case 4.4:** **Multiple Casualties.** Caller reports: "There was a balcony collapse, many people are hurt!" *Expected Outcome:* AI creates a report, dispatches the nearest AED, and **uses the `notifyPolice` tool**, noting a mass casualty incident.
*   **Case 4.5:** **Device Malfunction Scenario.** The nearest device is flagged as "Maintenance_Required." *Expected Outcome:* The system intelligently skips the broken device and dispatches the *next* nearest operational AED.
*   **Case 4.6:** **Caller Error Correction.** Caller first says "He's not breathing," then says, "Wait, he's gasping." *Expected Outcome:* AI triage correctly identifies gasping as a sign of cardiac arrest.
*   **Case 4.7:** **High-Stress, Frantic Caller.** Caller is shouting and providing information out of order. *Expected Outcome:* AI successfully extracts key details (location, patient condition) despite the chaotic input.
*   **Case 4.8:** **CPR In Progress.** Caller reports: "My husband collapsed, I'm already doing CPR!" *Expected Outcome:* AI creates report and focuses instructions on AED arrival and use.
*   **Case 4.9:** **Hoax Call Test.** Caller reports a fake incident with nonsensical details. *Expected Outcome:* AI classifies as "Other Medical" with a very low confidence score and provides clarifying questions that would likely expose the hoax.
