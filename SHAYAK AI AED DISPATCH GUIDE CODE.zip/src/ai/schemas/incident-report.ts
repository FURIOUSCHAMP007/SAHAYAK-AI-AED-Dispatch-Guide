/**
 * @fileOverview Defines the Zod schemas and TypeScript types for incident reporting and triage.
 */
import { z } from 'zod';

// === Incident Reporting Schemas ===

export const ReportIncidentInputSchema = z.object({
    callerName: z.string().describe('The name of the person reporting the incident.'),
    callerNumber: z.string().describe('The phone number of the person reporting.'),
    location: z.string().describe('The address or location description of the incident.'),
    incidentDetails: z.string().describe('A free-text description of what happened, including patient condition and any actions taken.'),
});
export type ReportIncidentInput = z.infer<typeof ReportIncidentInputSchema>;

export const ReportIncidentOutputSchema = z.object({
    incidentId: z.string().describe('A new unique ID for the incident, formatted as inc-XXX.'),
    deviceId: z.string().optional().describe('The ID of the nearest AED device, if one can be determined.'),
    deviceName: z.string().optional().describe('The name of the nearest AED device.'),
    location: z.string().describe('The address or location description of the incident.'),
    timestamp: z.string().describe('The current timestamp in ISO 8601 format.'),
    patientData: z.string().describe('A summary of the patient\'s apparent condition, age, and gender.'),
    eventLog: z.string().describe('A structured summary of the key events from the caller\'s description.'),
    ecgInsights: z.string().default('Not available from caller report.').describe('Default to "Not available from caller report."'),
    timeline: z.array(z.object({
        event: z.string(),
        time: z.string().describe('Time of the event in HH:MM:SS format.'),
    })).describe('A timeline of events extracted from the details.')
});
export type ReportIncidentOutput = z.infer<typeof ReportIncidentOutputSchema>;


// === Incident Triage Schemas ===

export const TriageIncidentInputSchema = z.object({
  incidentDetails: z.string().describe('A free-text description of what happened, including patient condition and any actions taken.'),
});
export type TriageIncidentInput = z.infer<typeof TriageIncidentInputSchema>;

export const TriageIncidentOutputSchema = z.object({
  incidentType: z.enum([
    "Cardiac Arrest",
    "Breathing Problem",
    "Chest Pain",
    "Fall / Injury",
    "Unconscious / Fainting",
    "Seizure",
    "Other Medical",
  ]).describe('The most likely type of incident based on the details provided.'),
  confidenceScore: z.number().min(0).max(100).describe('A confidence score (0-100) for the suggested incident type.'),
  keyFactors: z.array(z.string()).describe('A list of key words or phrases from the report that led to the classification.'),
  criticalQuestions: z.array(z.string()).describe('A list of critical questions the dispatcher should ask the caller based on the incident type.'),
});
export type TriageIncidentOutput = z.infer<typeof TriageIncidentOutputSchema>;
