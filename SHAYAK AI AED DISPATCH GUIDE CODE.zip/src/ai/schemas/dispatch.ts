/**
 * @fileOverview Defines the Zod schemas and TypeScript types for dispatch-related AI flows.
 */
import { z } from 'zod';

// === Hospital Recommendation Schemas ===

export const HospitalRecommendationInputSchema = z.object({
    incidentType: z.string().describe("The type of the medical incident (e.g., 'Cardiac Arrest', 'Trauma')."),
    hospitals: z.array(z.object({
        id: z.string(),
        name: z.string(),
        specialties: z.array(z.string()),
        bedAvailability: z.number(),
    })).describe("A list of available hospitals with their details.")
});
export type HospitalRecommendationInput = z.infer<typeof HospitalRecommendationInputSchema>;


export const HospitalRecommendationOutputSchema = z.object({
    recommendedHospitalId: z.string().describe("The ID of the best hospital for this incident."),
    reasoning: z.string().describe("A brief explanation for the recommendation."),
});
export type HospitalRecommendationOutput = z.infer<typeof HospitalRecommendationOutputSchema>;


// === Dispatch Package Schemas ===

export const DispatchPackageInputSchema = z.object({
    incidentType: z.string().describe("The type of the medical incident (e.g., 'Mass Casualty Incident')."),
    details: z.string().optional().describe("Any additional details about the incident."),
});
export type DispatchPackageInput = z.infer<typeof DispatchPackageInputSchema>;

export const DispatchPackageOutputSchema = z.object({
    requiredUnits: z.array(z.object({
        unitType: z.string().describe("The type of responder unit required (e.g., 'Type F (Disaster)', 'Type C (ALS)')."),
        quantity: z.number().describe("The number of units of this type required."),
    })).describe("A list of responder units and quantities needed for the incident."),
});
export type DispatchPackageOutput = z.infer<typeof DispatchPackageOutputSchema>;
