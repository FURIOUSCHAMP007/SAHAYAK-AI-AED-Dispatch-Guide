'use server';
import { config } from 'dotenv';
config();

import '@/ai/flows/incident-summarization.ts';
import '@/ai/flows/incident-analysis.ts';
import '@/ai/flows/predictive-maintenance.ts';
import '@/ai/flows/report-incident.ts';
import '@/ai/flows/cpr-analysis.ts';
import '@/ai/flows/incident-audio-summary.ts';
import '@/ai/flows/triage-incident.ts';
import '@/ai/flows/get-ai-hospital-recommendation.ts';
import '@/ai/flows/get-dispatch-package.ts';
import '@/ai/flows/incident-audio-summary.ts';
import '@/ai/flows/generate-cpr-aed-instructions.ts';
