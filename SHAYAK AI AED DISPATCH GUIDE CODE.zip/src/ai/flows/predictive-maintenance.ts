
'use server';

/**
 * @fileOverview This file defines a Genkit flow for predicting maintenance issues with AED devices.
 *
 * - predictMaintenanceNeeds - A function that takes device data and predicts potential maintenance needs.
 * - PredictiveMaintenanceInput - The input type for the predictMaintenanceNeeds function.
 * - PredictiveMaintenanceOutput - The return type for the predictMaintenanceNeeds function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PredictiveMaintenanceInputSchema = z.object({
  deviceId: z.string().describe('The unique identifier of the AED device.'),
  deviceLogs: z.string().describe('Logs from the AED device, including error messages and usage data.'),
  batteryLevel: z.number().describe('The current battery level of the AED device (0-100).'),
  usagePatterns: z.string().describe('Description of how often the AED device is used.'),
});
export type PredictiveMaintenanceInput = z.infer<typeof PredictiveMaintenanceInputSchema>;

const PredictiveMaintenanceOutputSchema = z.object({
  requiresMaintenance: z.boolean().describe('Whether the AED device is predicted to require maintenance.'),
  predictedMaintenanceType: z.string().describe('The predicted type of maintenance required (e.g., battery replacement, software update).'),
  urgencyScore: z.number().describe('A score (0-100) indicating the urgency of the predicted maintenance, with 100 being the most urgent.'),
  explanation: z.array(z.string()).describe('A list of key points explaining why the AI thinks maintenance is required.'),
});
export type PredictiveMaintenanceOutput = z.infer<typeof PredictiveMaintenanceOutputSchema>;

export async function predictMaintenanceNeeds(input: PredictiveMaintenanceInput): Promise<PredictiveMaintenanceOutput> {
  return predictiveMaintenanceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'predictiveMaintenancePrompt',
  input: {schema: PredictiveMaintenanceInputSchema},
  output: {schema: PredictiveMaintenanceOutputSchema},
  prompt: `You are an expert AI assistant specializing in predicting maintenance needs for Automated External Defibrillators (AEDs).

  Analyze the provided AED device data to determine if maintenance is required. Provide a predictedMaintenanceType, urgencyScore, and a point-wise explanation for your determination.

  Device ID: {{{deviceId}}}
  Device Logs: {{{deviceLogs}}}
  Battery Level: {{{batteryLevel}}}
  Usage Patterns: {{{usagePatterns}}}

  Based on this information, determine the following:
  - requiresMaintenance: Boolean indicating if maintenance is required.
  - predictedMaintenanceType: The type of maintenance that is predicted to be required.
  - urgencyScore: A score (0-100) indicating the urgency of the maintenance, with 100 being the most urgent.
  - explanation: A list of bullet points explaining why you believe maintenance is required, referencing specific data points from the provided information.
  `,
});

const predictiveMaintenanceFlow = ai.defineFlow(
  {
    name: 'predictiveMaintenanceFlow',
    inputSchema: PredictiveMaintenanceInputSchema,
    outputSchema: PredictiveMaintenanceOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
