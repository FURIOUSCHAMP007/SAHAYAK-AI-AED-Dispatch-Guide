'use server';
/**
 * @fileOverview A CPR analysis AI agent.
 *
 * - analyzeCprPerformance - A function that handles the CPR performance analysis.
 * - CprAnalysisInput - The input type for the analyzeCprPerformance function.
 * - CprAnalysisOutput - The return type for the analyzeCprPerformance function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CprAnalysisInputSchema = z.object({
  eventLog: z.string().describe('The event log of the incident, containing details about CPR actions.'),
});
export type CprAnalysisInput = z.infer<typeof CprAnalysisInputSchema>;

const CprAnalysisOutputSchema = z.object({
  feedback: z.string().describe('Detailed feedback on the CPR performance, including rate, depth, and any interruptions.'),
  recommendations: z.array(z.string()).describe('A list of actionable recommendations for improvement.'),
  cprScore: z.number().describe('An overall CPR quality score from 0 to 100.'),
});
export type CprAnalysisOutput = z.infer<typeof CprAnalysisOutputSchema>;

export async function analyzeCprPerformance(input: CprAnalysisInput): Promise<CprAnalysisOutput> {
  return cprAnalysisFlow(input);
}

const prompt = ai.definePrompt({
  name: 'cprAnalysisPrompt',
  input: {schema: CprAnalysisInputSchema},
  output: {schema: CprAnalysisOutputSchema},
  prompt: `You are an expert CPR performance analyst, acting as the "AI Eyes" for the SAHAYAK device. Your role is to analyze the event log from a cardiac arrest incident and provide a detailed report on the quality of CPR administered.

You must analyze the log for details about compression rate, depth, hand placement, and interruptions. Based on this analysis, provide constructive feedback, a list of recommendations, and an overall quality score.

Event Log:
{{{eventLog}}}

Analyze the log and generate the CPR quality report.
`,
});

const cprAnalysisFlow = ai.defineFlow(
  {
    name: 'cprAnalysisFlow',
    inputSchema: CprAnalysisInputSchema,
    outputSchema: CprAnalysisOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
