
'use server';

/**
 * @fileOverview An AI flow for recommending a full dispatch package for complex incidents.
 */

import { ai } from '@/ai/genkit';
import { 
    DispatchPackageInputSchema,
    DispatchPackageOutputSchema,
    type DispatchPackageInput,
    type DispatchPackageOutput
} from '@/ai/schemas/dispatch';

export async function getDispatchPackage(input: DispatchPackageInput): Promise<DispatchPackageOutput> {
    return dispatchPackageFlow(input);
}

const prompt = ai.definePrompt({
    name: 'dispatchPackagePrompt',
    input: { schema: DispatchPackageInputSchema },
    output: { schema: DispatchPackageOutputSchema },
    prompt: `You are an expert emergency services dispatcher. Your task is to determine the optimal package of responder units for a complex incident.

    Incident Type: {{{incidentType}}}
    {{#if details}}
    Additional Details: {{{details}}}
    {{/if}}

    Based on the incident type, recommend the necessary units and their quantities. For example, a "Mass Casualty Incident" might require a disaster unit, multiple advanced life support ambulances, and police support. A standard incident might only require one or two specific units.
    
    Return the list of required units.
    `,
});

const dispatchPackageFlow = ai.defineFlow(
    {
        name: 'dispatchPackageFlow',
        inputSchema: DispatchPackageInputSchema,
        outputSchema: DispatchPackageOutputSchema,
    },
    async (input) => {
        const { output } = await prompt(input);
        return output!;
    }
);
