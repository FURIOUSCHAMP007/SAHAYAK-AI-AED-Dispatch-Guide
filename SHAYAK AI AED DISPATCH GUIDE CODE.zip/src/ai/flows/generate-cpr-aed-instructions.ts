
'use server';

/**
 * @fileOverview A flow for generating a text-to-speech audio guide for CPR and AED instructions.
 */
import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import wav from 'wav';
import { malePatientScript, femalePatientScript, type ScriptItem } from '@/lib/scripts';

// Define a more specific schema for a single script item
const ScriptItemSchema = z.object({
  type: z.enum(['heading', 'text', 'image', 'space']),
  content: z.string(),
  alt: z.string().optional(),
  hint: z.string().optional(),
  speaker: z.enum(['Instructor 1', 'Instructor 2']).optional(),
});

const CprAedInstructionsInputSchema = z.object({
  scenario: z.enum(['male', 'female']).describe('The patient scenario for which to generate instructions.'),
});
export type CprAedInstructionsInput = z.infer<typeof CprAedInstructionsInputSchema>;

const CprAedInstructionsOutputSchema = z.object({
  audioDataUri: z.string().describe("The generated audio as a data URI in WAV format. Expected format: 'data:audio/wav;base64,<encoded_data>'."),
  script: z.array(ScriptItemSchema).describe('The full script that was used to generate the audio.'),
});
export type CprAedInstructionsOutput = z.infer<typeof CprAedInstructionsOutputSchema>;

export async function generateCprAedInstructions(input: CprAedInstructionsInput): Promise<CprAedInstructionsOutput> {
    return cprAedInstructionsFlow(input);
}

// Function to convert PCM audio buffer to WAV base64 string
async function toWav(
  pcmData: Buffer,
  channels = 1,
  rate = 24000,
  sampleWidth = 2
): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    const bufs: Buffer[] = [];
    writer.on('error', reject);
    writer.on('data', (d) => {
      bufs.push(d);
    });
    writer.on('end', () => {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}

// The main Genkit flow
const cprAedInstructionsFlow = ai.defineFlow(
    {
      name: 'cprAedInstructionsFlow',
      inputSchema: CprAedInstructionsInputSchema,
      outputSchema: CprAedInstructionsOutputSchema,
    },
    async ({ scenario }) => {
        // Step 1: Select the script based on the scenario
        const scriptToUse: ScriptItem[] = scenario === 'male' ? malePatientScript : femalePatientScript;
        
        // Step 2: Convert the script object array into a single string with speaker tags
        const ttsPrompt = scriptToUse
            .filter(item => item.type === 'text' || item.type === 'heading')
            .map(item => {
                // Default to Speaker1 if no speaker is defined
                const speaker = item.speaker === 'Instructor 2' ? 'Speaker2' : 'Speaker1';
                return `${speaker}: ${item.content}`;
            })
            .join('\n');

        // Step 3: Generate the audio
        const { media } = await ai.generate({
            model: 'googleai/gemini-2.5-flash-preview-tts',
            config: {
                responseModalities: ['AUDIO'],
                speechConfig: {
                    multiSpeakerVoiceConfig: {
                        speakerVoiceConfigs: [
                            {
                                speaker: 'Speaker1',
                                voiceConfig: {
                                    prebuiltVoiceConfig: { voiceName: 'Algenib' }, // A calm, clear female voice
                                },
                            },
                            {
                                speaker: 'Speaker2',
                                voiceConfig: {
                                    prebuiltVoiceConfig: { voiceName: 'Puck' }, // A clear male voice
                                },
                            },
                        ],
                    },
                },
            },
            prompt: ttsPrompt,
        });

        if (!media || !media.url) {
            throw new Error('Text-to-speech generation failed to return audio.');
        }

        // Step 4: Convert audio to WAV format
        const audioBuffer = Buffer.from(
            media.url.substring(media.url.indexOf(',') + 1),
            'base64'
        );

        const wavBase64 = await toWav(audioBuffer);
        
        // Step 5: Return both the audio and the script
        return {
            audioDataUri: `data:audio/wav;base64,${wavBase64}`,
            script: scriptToUse,
        };
    }
);
