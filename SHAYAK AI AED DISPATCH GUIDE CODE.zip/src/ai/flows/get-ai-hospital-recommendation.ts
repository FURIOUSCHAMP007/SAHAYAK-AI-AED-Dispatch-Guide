
'use server';

/**
 * @fileOverview An AI flow for recommending the best hospital for an incident.
 */

import { ai } from '@/ai/genkit';
import { 
    HospitalRecommendationInputSchema,
    HospitalRecommendationOutputSchema,
    type HospitalRecommendationInput,
    type HospitalRecommendationOutput
} from '@/ai/schemas/dispatch';

export async function getAIHospitalRecommendation(input: HospitalRecommendationInput): Promise<HospitalRecommendationOutput> {
    return hospitalRecommendationFlow(input);
}

const prompt = ai.definePrompt({
    name: 'hospitalRecommendationPrompt',
    input: { schema: HospitalRecommendationInputSchema },
    output: { schema: HospitalRecommendationOutputSchema },
    prompt: `You are an expert medical dispatcher. Your task is to recommend the best hospital for a patient based on the incident type and the available hospitals.

    Incident Type: {{{incidentType}}}

    Available Hospitals:
    {{#each hospitals}}
    - ID: {{id}}, Name: {{name}}, Specialties: [{{#each specialties}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}], Beds Available: {{bedAvailability}}
    {{/each}}

    Consider the following criteria for your recommendation:
    1.  Specialties: The hospital must have the appropriate specialty for the incident type (e.g., Cardiology for Cardiac Arrest, Trauma for accidents).
    2.  Bed Availability: The hospital must have available beds.
    3.  Prioritize specialized care over general care if possible.

    Based on these criteria, choose the single best hospital and provide a brief reason for your choice.
    `,
});

const hospitalRecommendationFlow = ai.defineFlow(
    {
        name: 'hospitalRecommendationFlow',
        inputSchema: HospitalRecommendationInputSchema,
        outputSchema: HospitalRecommendationOutputSchema,
    },
    async (input) => {
        const { output } = await prompt(input);
        return output!;
    }
);
