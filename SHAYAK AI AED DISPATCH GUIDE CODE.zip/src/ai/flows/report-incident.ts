'use server';

/**
 * @fileOverview A flow for creating a structured incident report from a caller's raw input.
 * 
 * - reportIncident - A function that takes a caller's report and returns a structured incident object.
 */

import { ai } from '@/ai/genkit';
import { 
    ReportIncidentInputSchema, 
    ReportIncidentOutputSchema,
    type ReportIncidentInput,
    type ReportIncidentOutput
} from '@/ai/schemas/incident-report';
import { findNearestDevice } from '@/lib/dispatch';
import { z } from 'zod';


export async function reportIncident(input: ReportIncidentInput): Promise<ReportIncidentOutput> {
    return reportIncidentFlow(input);
}

const findNearestDeviceTool = ai.defineTool(
    {
        name: 'findNearestDevice',
        description: 'Finds the nearest available AED device to a given location string.',
        inputSchema: z.object({ location: z.string() }),
        outputSchema: z.object({
            id: z.string(),
            name: z.string(),
            address: z.string(),
        }).nullable(),
    },
    async ({ location }) => {
        return findNearestDevice(location);
    }
);

const notifyPoliceTool = ai.defineTool(
    {
        name: 'notifyPolice',
        description: 'Notifies the local police department about an incident that may require their presence.',
        inputSchema: z.object({ 
            location: z.string(),
            reason: z.string().describe("A brief explanation of why police presence is required."),
        }),
        outputSchema: z.object({
            confirmationNumber: z.string(),
            dispatched: z.boolean(),
        }),
    },
    async ({ location, reason }) => {
        console.log(`Police notified for incident at ${location}. Reason: ${reason}`);
        // In a real app, this would be an API call.
        return {
            confirmationNumber: `POL-${Date.now()}`,
            dispatched: true,
        };
    }
);

const notifySocialServicesTool = ai.defineTool(
    {
        name: 'notifySocialServices',
        description: 'Alerts social services for incidents involving vulnerable persons or requiring social support.',
        inputSchema: z.object({
            location: z.string(),
            reason: z.string().describe("A brief explanation of why social services support is needed."),
        }),
        outputSchema: z.object({
            caseId: z.string(),
            referralStatus: z.string(),
        }),
    },
    async ({ location, reason }) => {
        console.log(`Social services notified for incident at ${location}. Reason: ${reason}`);
        // In a real app, this would be an API call.
        return {
            caseId: `SOC-${Date.now()}`,
            referralStatus: "Pending Review",
        };
    }
);


const reportIncidentFlow = ai.defineFlow(
  {
    name: 'reportIncidentFlow',
    inputSchema: ReportIncidentInputSchema,
    outputSchema: ReportIncidentOutputSchema,
    tools: [findNearestDeviceTool, notifyPoliceTool, notifySocialServicesTool],
  },
  async (input) => {
    const prompt = `You are an expert emergency dispatcher AI. Your task is to take a raw incident report from a caller and structure it into a formal incident record. You must also determine if police or social services need to be notified.

The current time is ${new Date().toISOString()}. Generate a new unique incident ID starting with 'inc-' followed by a short alphanumeric string.

Caller Report:
- Name: {{{callerName}}}
- Phone: {{{callerNumber}}}
- Location: {{{location}}}
- Details: {{{incidentDetails}}}

Based on the report, perform these steps:
1.  Create a structured incident record. Summarize the patient data, create a log of events, and build a timeline.
2.  Use the findNearestDevice tool to identify the closest AED. You MUST always call this tool.
3.  Analyze the incident details. If there is any mention of public disturbance, assault, crime, or a security threat, you MUST use the notifyPolice tool.
4.  Analyze the incident details. If the report involves a person who is homeless, in a mental health crisis, or a vulnerable individual needing support, you MUST use the notifySocialServices tool.
5.  Include the deviceId and deviceName from the findNearestDevice tool's output in your response. If no device is found, you can leave those fields empty.
`;
      
    const {output} = await ai.generate({
      prompt,
      model: 'googleai/gemini-2.5-flash',
      input: input,
      output: { schema: ReportIncidentOutputSchema },
      tools: [findNearestDeviceTool, notifyPoliceTool, notifySocialServicesTool],
    });
    return output!;
  }
);
