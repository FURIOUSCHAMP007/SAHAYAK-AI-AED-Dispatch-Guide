'use server';
/**
 * @fileOverview Incident analysis AI agent.
 *
 * - analyzeIncident - A function that handles the incident analysis process.
 * - AnalyzeIncidentInput - The input type for the analyzeIncident function.
 * - AnalyzeIncidentOutput - The return type for the analyzeIncident function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeIncidentInputSchema = z.object({
  eventLog: z.string().describe('The event log of the incident.'),
  ecgDataUrl: z
    .string()
    .describe(
      'The ECG data as a data URI that must include a MIME type and use Base64 encoding. Expected format: data:<mimetype>;base64,<encoded_data>.'
    ),
});
export type AnalyzeIncidentInput = z.infer<typeof AnalyzeIncidentInputSchema>;

const AnalyzeIncidentOutputSchema = z.object({
  eventSequence: z.array(z.string()).describe('A point-wise summary of the sequence of events from the event log.'),
  possibleCauses: z.array(z.object({
    cause: z.string().describe('A potential cause for the incident, like "Acute Coronary Syndrome".'),
    explanation: z.string().describe('A brief explanation of why this is a possible cause.'),
  })).describe('A list of possible causes and contributing factors for the shockable rhythm detected.'),
  conclusion: z.string().describe('A concluding remark about what is needed for a precise diagnosis, mentioning the need for an actual ECG tracing.'),
  initialAssessment: z.string().describe('A brief, one-sentence initial assessment of the situation based on the event log.'),
});

export type AnalyzeIncidentOutput = z.infer<typeof AnalyzeIncidentOutputSchema>;

export async function analyzeIncident(input: AnalyzeIncidentInput): Promise<AnalyzeIncidentOutput> {
  return analyzeIncidentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeIncidentPrompt',
  input: {schema: AnalyzeIncidentInputSchema},
  output: {schema: AnalyzeIncidentOutputSchema},
  prompt: `You are an expert medical incident analyst. Your task is to analyze an incident based on an event log and an associated image, which is supposed to be ECG data.

First, verify the image. If the image provided in 'ecgDataUrl' is not a medical electrocardiogram (ECG) waveform, state that clearly in your initial assessment.

Based *only* on the event log, provide a structured analysis of the incident.

Event Log: {{{eventLog}}}
ECG Data: {{media url=ecgDataUrl}}

Your analysis must be structured as follows:
1.  **initialAssessment**: A single sentence summarizing the situation based on the event log and confirming if the ECG image is valid.
2.  **eventSequence**: A bulleted list summarizing the key events from the log in chronological order.
3.  **possibleCauses**: Based on the event log indicating a shockable cardiac arrest, list several common medical causes. For each cause, provide a brief explanation.
4.  **conclusion**: A concluding sentence stating what is required for a definitive diagnosis.
`,
});

const analyzeIncidentFlow = ai.defineFlow(
  {
    name: 'analyzeIncidentFlow',
    inputSchema: AnalyzeIncidentInputSchema,
    outputSchema: AnalyzeIncidentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
