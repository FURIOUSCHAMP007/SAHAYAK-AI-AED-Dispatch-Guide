'use server';

/**
 * @fileOverview Incident summarization AI agent.
 *
 * - summarizeIncident - A function that summarizes incident details.
 * - IncidentSummarizationInput - The input type for the summarizeIncident function.
 * - IncidentSummaryOutput - The return type for the summarizeIncident function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const IncidentSummarizationInputSchema = z.object({
  patientData: z.string().describe('Summary of patient data involved in the incident.'),
  eventLog: z.string().describe('Highlights from the event log during the incident.'),
  ecgInsights: z.string().describe('Insights derived from the ECG data analysis.'),
});

export type IncidentSummarizationInput = z.infer<typeof IncidentSummarizationInputSchema>;

const IncidentSummaryOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the key details of the incident.'),
});

export type IncidentSummaryOutput = z.infer<typeof IncidentSummaryOutputSchema>;

export async function summarizeIncident(input: IncidentSummarizationInput): Promise<IncidentSummaryOutput> {
  return summarizeIncidentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'incidentSummarizationPrompt',
  input: {schema: IncidentSummarizationInputSchema},
  output: {schema: IncidentSummaryOutputSchema},
  prompt: `You are an AI assistant that specializes in summarizing incident details for administrators.

  Given the following information, create a concise summary of the key details of the incident.

  Patient Data: {{{patientData}}}
  Event Log Highlights: {{{eventLog}}}
  ECG Insights: {{{ecgInsights}}}
  `,
});

const summarizeIncidentFlow = ai.defineFlow(
  {
    name: 'summarizeIncidentFlow',
    inputSchema: IncidentSummarizationInputSchema,
    outputSchema: IncidentSummaryOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
