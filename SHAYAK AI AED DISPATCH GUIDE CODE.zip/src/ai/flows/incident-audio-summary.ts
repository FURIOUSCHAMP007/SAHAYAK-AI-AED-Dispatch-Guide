'use server';

/**
 * @fileOverview A flow for generating a text-to-speech audio summary of an incident.
 *
 * - generateIncidentAudioSummary - Creates an audio file from an incident summary.
 */
import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import wav from 'wav';
import { summarizeIncident } from './incident-summarization';
import type { Incident } from '@/types';

const IncidentAudioSummaryInputSchema = z.object({
  incident: z.any().describe('The full incident object, containing patient data, event logs, etc.'),
});
export type IncidentAudioSummaryInput = z.infer<typeof IncidentAudioSummaryInputSchema>;

const IncidentAudioSummaryOutputSchema = z.object({
  audioDataUri: z.string().describe("The generated audio as a data URI in WAV format. Expected format: 'data:audio/wav;base64,<encoded_data>'."),
  textSummary: z.string().describe('The text summary that was converted to audio.'),
});
export type IncidentAudioSummaryOutput = z.infer<typeof IncidentAudioSummaryOutputSchema>;

export async function generateIncidentAudioSummary(input: IncidentAudioSummaryInput): Promise<IncidentAudioSummaryOutput> {
    return incidentAudioSummaryFlow(input);
}

async function toWav(
  pcmData: Buffer,
  channels = 1,
  rate = 24000,
  sampleWidth = 2
): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    const bufs: Buffer[] = [];
    writer.on('error', reject);
    writer.on('data', (d) => {
      bufs.push(d);
    });
    writer.on('end', () => {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}


const incidentAudioSummaryFlow = ai.defineFlow(
    {
      name: 'incidentAudioSummaryFlow',
      inputSchema: IncidentAudioSummaryInputSchema,
      outputSchema: IncidentAudioSummaryOutputSchema,
    },
    async ({ incident } : { incident: Incident }) => {

        // Step 1: Generate the text summary
        const { summary: textSummary } = await summarizeIncident({
            patientData: incident.patientData,
            eventLog: incident.eventLog,
            ecgInsights: incident.ecgInsights,
        });

        // Step 2: Generate the TTS audio from the summary
        const ttsPrompt = `You are the AI Voice for the SAHAYAK device. Read the following incident summary in a clear, calm, and authoritative voice suitable for a medical debrief.
        
        Summary: ${textSummary}`;

        const { media } = await ai.generate({
            model: 'googleai/gemini-2.5-flash-preview-tts',
            config: {
                responseModalities: ['AUDIO'],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Algenib' },
                    },
                },
            },
            prompt: ttsPrompt,
        });

        if (!media || !media.url) {
            throw new Error('Text-to-speech generation failed to return audio.');
        }

        const audioBuffer = Buffer.from(
            media.url.substring(media.url.indexOf(',') + 1),
            'base64'
        );

        const wavBase64 = await toWav(audioBuffer);
        
        return {
            audioDataUri: `data:audio/wav;base64,${wavBase64}`,
            textSummary: textSummary,
        };
    }
);
