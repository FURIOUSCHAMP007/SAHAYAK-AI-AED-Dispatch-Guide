'use server';

/**
 * @fileOverview An AI flow for triaging an incident report.
 * This flow analyzes a raw report, suggests an incident type, provides a confidence score,
 * and extracts key factors that influenced its decision.
 */

import { ai } from '@/ai/genkit';
import { 
    TriageIncidentInputSchema, 
    TriageIncidentOutputSchema, 
    TriageIncidentInput, 
    TriageIncidentOutput 
} from '@/ai/schemas/incident-report';


export async function triageIncident(input: TriageIncidentInput): Promise<TriageIncidentOutput> {
  return triageIncidentFlow(input);
}


const prompt = ai.definePrompt({
  name: 'triageIncidentPrompt',
  input: { schema: TriageIncidentInputSchema },
  output: { schema: TriageIncidentOutputSchema },
  prompt: `You are an expert emergency dispatcher AI. Your task is to analyze a raw incident report and triage it.

  Incident Details:
  "{{{incidentDetails}}}"

  Based on the details, perform the following actions:
  1.  Classify the incident into one of the predefined types.
  2.  Provide a confidence score for your classification.
  3.  Extract the key phrases or factors from the report that justify your classification.
  4.  Generate a list of 2-3 critical questions the dispatcher should ask the caller to gather more information, tailored to the incident type. For example, for "Cardiac Arrest", you might suggest asking "Is the patient breathing normally?" or "Is the person completely unresponsive?". For "Fall / Injury", you might ask "Is there any serious bleeding?" or "Did the person hit their head?".
  
  Provide the output in the required structured format.
  `,
});


const triageIncidentFlow = ai.defineFlow(
  {
    name: 'triageIncidentFlow',
    inputSchema: TriageIncidentInputSchema,
    outputSchema: TriageIncidentOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);
