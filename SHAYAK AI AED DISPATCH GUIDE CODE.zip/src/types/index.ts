




export type DeviceStatus = "Operational" | "Active_Incident" | "Maintenance_Required";

export interface AEDDevice {
  id: string;
  name: string;
  location: {
    lat: number;
    lng: number;
  };
  address: string;
  batteryLevel: number;
  status: DeviceStatus;
  lastMaintenance: string;
  deviceLogs: string;
  usagePatterns: string;
}

export interface Incident {
  id: string;
  deviceId: string;
  deviceName: string;
  location: string;
  timestamp: string;
  incidentType: string;
  patientData: string;
  eventLog: string;
  ecgDataUrl: string; // URL to an image of the ECG data
  ecgInsights: string;
  timeline: {
    event: string;
    time: string;
  }[];
  // Fields for dispatch system
  lat?: number;
  lng?: number;
  dispatched?: boolean;
}

export type ResponderStatus = "Available" | "Enroute to Incident" | "On Scene" | "Enroute to Hospital" | "Returning to Base" | "Out of Service" | "At Hospital";

export interface ResponderUnit {
    id: string;
    unitType: string; // e.g., 'Type C (ALS)', 'Police Car', 'Social Service Worker'
    status: ResponderStatus;
    currentLocation: {
        lat: number;
        lng: number;
    };
    baseLocation: {
        lat: number;
        lng: number;
    };
    assignedIncidentId?: string | null;
    route?: any; // GeoJSON route data
    destination?: { lat: number; lng: number };
    eta?: number; // minutes
    lastUpdate?: number; // timestamp for movement calculation
    distanceTraveled?: number; // km
}

export interface IncidentType {
    name: string;
    recommendedUnit: string;
    requiresPackage: boolean;
}

export interface Hospital {
    id: string;
    name: string;
    location: {
        lat: number;
        lng: number;
    };
    specialties: string[];
    bedAvailability: number;
}
